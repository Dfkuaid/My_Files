#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 50010;
const int INF = 0x3fffffff;

struct Hurdle{
    int a;
    int b;
    int c;
};
Hurdle h[N];

int n,x,f[N][201],q[201][N];
int frt[201],tal[201];

int main(){
    mset(tal,-1);
    mset(f,0x3f);
    scanf("%d%d",&n,&x);
    x /= 100;
    for (int i = 1;i <= n;i ++){
    	int a,b,c;
    	scanf("%d%d%d",&a,&b,&c);
    	h[i].a = a / 100;
    	h[i].b = b / 100;
    	h[i].c = c;
	}
      
    f[1][x] = 1;
    q[h[1].b + x][++ tal[h[1].b + x]] = 1;
    
    for (int i = 2;i <= n;i++){
        for (int j = 100;j >= h[i].a;j --){
        	int nxt = j + h[i].b;
            while (frt[j] <= tal[j] && q[j][frt[j]] < i - h[i].c)
              frt[j] ++;
            if (frt[j] <= tal[j])
              f[i][j] = f[q[j][frt[j]]][j - h[q[j][frt[j]]].b] + 1;
            while (frt[nxt] <= tal[nxt] && f[q[nxt][tal[nxt]]][nxt - h[q[nxt][tal[nxt]]].b] >= f[i][j])
              tal[nxt] --;
            q[nxt][++ tal[nxt]] = i;
        }
    }
    
    int minn = INF;
    for (int i = 0;i <= 100;i ++)
      minn = min(minn,f[n][i]);
    if (minn > n) cout << "+200";
    else cout << minn;
    return 0;
}
