#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 5010;
const int MOD = 4999;
const int INF = 0x3fffffff;

ll t,n,m,c[N][N],ans,coe[2][5];
ll p[5] = {1,4999,24990001,124925014999,624500149980001};

inline void pre_c(){
    for (int i = 0;i < N;i ++)
      for (int j = 0;j <= i;j ++)
      	if (i == j || j == 0) c[i][j] = 1;
      	else c[i][j] = (c[i - 1][j] + c[i - 1][j - 1]) % MOD;
}

inline void get_coe(ll x,int rel){
    int last = 4;
    while (x > 0){
        while (x < p[last])
          last --;
        coe[rel][last] = x / p[last];
        x -= coe[rel][last] * p[last];
    }
}

int main(){
    pre_c();
    scanf("%d",&t);
    while (t --){
        scanf("%d%d",&n,&m);
        ans = 1;
        mset(coe,0);
        get_coe(m + n + 2,0);
        get_coe(m + 1,1);
        for (int i = 0;i <= 4;i ++)
          ans = (ans * c[coe[0][i]][coe[1][i]]) % MOD;
        printf("%lld\n",((ans - 2) % MOD + MOD) % MOD);
    }
    return 0;
}
