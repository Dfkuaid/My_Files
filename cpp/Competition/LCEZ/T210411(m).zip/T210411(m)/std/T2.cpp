#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 19260820;
const int MOD = 19260817;
const int INF = 0x3fffffff;

ll t,k,n,m,tms[N],ans;

inline ll qpower(ll a,int b){
	ll res = 1;
	while (b){
		if (b & 1)
		  res = (res * a) % MOD;
		b >>= 1;
		a = (a * a) % MOD;
	}
	return res;
}

inline int C(int i,int j){
    if (i < j) return 0;
    if (j == 0) return 1;
    return tms[i] * qpower(tms[j],MOD - 2) % MOD * qpower(tms[i - j],MOD - 2) % MOD;
}

int main(){
    tms[0] = 1;
    for (int i = 1;i < N;i ++)
      tms[i] = (tms[i - 1] * i) % MOD;
    scanf("%lld",&t);
    while (t --){
        scanf("%lld%lld",&n,&m);
        ans = 1;
        ll a = m + n + 2,b = m + 1;
        while (a >= MOD || b >= MOD){
        	(ans *= C(a % MOD,b % MOD)) %= MOD;
        	a /= MOD;b /= MOD;
        	if (!a) break;
		}
		(ans *= C(a,b)) %= MOD;
        printf("%lld\n",((ans - 2) % MOD + MOD) % MOD);
    }
    return 0;
}
