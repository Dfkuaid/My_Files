#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#define ll long long
using namespace std;

const int T2 = 100; 
const int T6 = 1e6;
const ll T18 = 1e18;

inline int random(){
    return (ll)rand() * rand() % T6;
}

inline ll random_18(){
    return ((ll)rand() * (ll)rand() * (ll)rand() * (ll)rand() + (ll)rand()) % T18;
}

int main(){
    freopen ("cards1.in","w",stdout);
    srand((unsigned)time(0));
    int t = random();
    printf("%d\n",t);
    while (t --){
        ll n,m;
        if (rand() % 2)
          n = random_18();
        else 
          n = random();
        if (rand() % 2)
          m = random();
        else 
          m = random_18();
        printf("%lld %lld\n",n,m);
    }
    return 0;
}
