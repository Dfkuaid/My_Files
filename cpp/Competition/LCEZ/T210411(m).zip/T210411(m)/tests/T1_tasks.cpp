#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#define ll long long
using namespace std;

const int T5 = 1e5;

int ans[100010][4];
int n,cnt,avg,fl;

inline int random(int x){
    return ((ll)rand() * rand() + rand()) % x;
}

inline void ran_g(){
    for (int i = 2;i <= fl;i ++){
        if (ans[i][0]) continue;
        ans[i][0] = i;
//        int k = 
        ans[i][1] = max(ans[i - 1][1],1);
        ans[i][2] = min(ans[i - rand() % 2 + 1][2] + (rand() % 2) * 100,10000);
        ans[i][3] = (random(10)) * 100;
        if (ans[i][2] + ans[i][3] > 10000)
          ans[i][3] = 10000 - ans[i][2];
//        cout << i << " " << ans[i][0] << " " << ans[i][1]  << " " << ans[i][2] << " " << ans[i][3]<< endl;
    }
}

inline void ans_g(){
    ans[0][1] = 100000;int last = 1;
    for (int i = 2;i <= cnt;i ++){
        int x = max(min(random(ans[last][1]) + ans[last][0],n),ans[last][0] + 1);
        ans[x][0] = x;
        ans[x][1] = min((random(n)) + ans[x][0] - ans[last][0],ans[last][1]);
        ans[x][1] = max(ans[x][1],1);
        ans[x][2] = min(ans[last][2] + (rand() % 2) * 100,10000);
        ans[x][3] = ans[x][2] == 10000 ? 0 : 100;
        last = x;
        fl = x;
//        cout << x << " " << ans[x][0] << " " << ans[x][1]  << " " << ans[x][2] << endl;
    }
}

int main(){
    freopen ("relax.in","w",stdout);
    srand((unsigned)time(0));
    int x = 100;
    n = random(15000),cnt = random(n);int c = n;
    avg = n / cnt;
    ans[1][0] = 1,ans[1][1] = n,ans[1][2] = 0,ans[1][3] = 0;
    ans_g();
    printf("%d %d\n",fl,x);
    ran_g();
    
    for (int i = 1;i <= fl;i ++)
      printf("%d %d %d\n",ans[i][2],ans[i][3],ans[i][1]);
    cout << cnt;
//    cout << 0 << " " << 100 << " " << 10 << "\n";
//    for (int i = 2;i <= n;i ++){
//        int a = random(50);
//        int b = random(100);
//        c = c - random(10);
//        c = max(c,0);
//        printf("%d %d %d\n",a * 100,b * 100,c);
//    }
}

/*
1 23 26
2 24 2
3 25 2
4 26 2
5 27 2
6 28 2
7 29 2
8 30 2
9 31 2
10 32 2
11 33 1
12 34 1
13 35 1
14 36 1
15 37 1
37 100
*/
