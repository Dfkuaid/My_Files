#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#define ll long long
using namespace std;

int main(){
    for (int T = 1;T <= 1000;T ++){
    	cout << "?\n";
        system("D:\\dykt2\\T2_tasks.exe");
        cout << "!\n";
        double st1 = clock();
        system("D:\\dykt2\\T2_1926.exe");
        double ed1 = clock();
        double st2 = clock();
        system("D:\\dykt2\\hyl.exe");
        double ed2 = clock();
        if (system("fc D:\\dykt2\\out1.txt D:\\dykt2\\out2.txt")){
            puts("Wrong Answer!\n");
            return 0;
        }
        else printf("Accepted,#%d,D:%.0fms,H:%.0fms\n",T,ed1 - st1,ed2 - st2);
    }
}
