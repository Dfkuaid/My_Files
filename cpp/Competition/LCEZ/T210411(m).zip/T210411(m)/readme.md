注意，T1 题面及题解中的

$$
p = 7^{362},q=49^{4}\\
M\equiv2\times(p-\left\lfloor\dfrac{p}{100}\right\rfloor + q-\left\lfloor\dfrac{q}{15}\right\rfloor)(\text{mod }100)
$$

都应当改为

$$
p = 7^{362},q=49^{4}\\
M\equiv2\times(p-\left\lfloor\dfrac{p}{100}\right\rfloor\times100 + q-\left\lfloor\dfrac{q}{15}\right\rfloor\times15)(\text{mod }100)
$$
