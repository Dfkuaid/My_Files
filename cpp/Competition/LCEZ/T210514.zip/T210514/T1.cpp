#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 110;
const int MOD = 998244353;
const int INF = 0x3fffffff;



int main(){
    return 0;
}