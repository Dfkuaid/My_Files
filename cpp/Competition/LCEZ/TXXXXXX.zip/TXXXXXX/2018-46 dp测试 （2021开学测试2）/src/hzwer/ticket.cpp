#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>
#define inf 2000000000
#define ll long long 
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int base[15];
int l,r;
int f[15][10];
void pre()
{
	for(int i=0;i<=9;i++)
		if(i!=4)f[1][i]=1;
	for(int i=2;i<=10;i++)
		for(int j=0;j<=9;j++)
			for(int k=0;k<=9;k++)
				if(j!=4&&k!=4&&(j!=3||k!=7))
					f[i][j]+=f[i-1][k];
}
int dp(int x)
{
	if(!x)return 0;
	int ans=0;
	int pre=0,cur,L=10;
	while(base[L]>x)L--;
	for(int i=1;i<L;i++)
		for(int j=1;j<=9;j++)
			ans=ans+f[i][j];
	cur=x/base[L];x%=base[L];
	if(L==1)
 		for(int i=1;i<=cur;i++)
 			ans=ans+f[L][i];
	else for(int i=1;i<cur;i++)
		ans=ans+f[L][i];
	pre=cur;
	for(int i=L-1;i;i--)
	{
		if(cur==4)continue;
		cur=x/base[i];x%=base[i];
		if(i==1)
		{
			for(int t=0;t<=cur;t++)
				if(pre!=3||t!=7)
					ans+=f[i][t];
		}
		else 
		{
			for(int t=0;t<cur;t++)
				if(pre!=3||t!=7)
					ans+=f[i][t];
		}
		if(pre==3&&cur==7)break;
		pre=cur;
	}
	return ans;
}
int main()
{
	freopen("ticket.in","r",stdin);
	freopen("ticket.out","w",stdout);
	base[1]=1;for(int i=2;i<=10;i++)base[i]=base[i-1]*10;
	pre();
	scanf("%d%d",&l,&r);
	printf("%d\n",dp(r)-dp(l-1));
	return 0;
}
