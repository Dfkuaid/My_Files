#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 1010;
const int INF = 0x3fffffff;

char a[N],key[10];
int b[N];
int l,k,t;

int main(){
    scanf("%d%d",&l,&k);
    for (int i = 0;i < l;i ++)
      cin >> a[i];
    for (int i = 0;i < k;i ++)
      cin >> key[i];
    for (int i = 0;i < l;i ++){
        b[i] = a[i] + key[t] - '0';
        if (b[i] > 'z') b[i] -= 26;
        (t += 1) %= k;
    }
    for (int i = 0;i < l;i ++)
      printf("%c",b[i],b[i]);
    return 0;
}
