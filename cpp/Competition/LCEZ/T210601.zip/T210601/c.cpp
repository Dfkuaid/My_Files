#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 10;
const int INF = 0x3fffffff;

int T,n,st[N],s;
ll k[N];
queue <int> q;

int main(){
    scanf("%d",&T);
    while (T --){
        scanf("%d",&n);
        for (int i = 1;i <= n;i ++){
            scanf("%d",&k[i]);
            st[i] = k[i];
        }
        sort(st + 1,st + n + 1);
        cnt = unique(st + 1,st + n + 1) - st - 1;
        for (int i = 1;i <= n;i ++)
        k[i] = lower_bound(st + 1,st + n + 1,k[i]) - st;
        for (int i = 1;i <= n;i ++)
          s = s * 10 + k[i];
    }
    
    return 0;
}