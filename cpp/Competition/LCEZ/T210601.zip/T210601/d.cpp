#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 300010;
const int M = 10010;
const int INF = 0x3fffffff;

int T,n,m,x,y,f[N],w1[M],w2[M];

inline int Max(const int &a,const int &b){
    return a > b ? a : b;
}

int main(){
    scanf("%d",&T);
    while (T --){
        mset(f,0);
        scanf("%d%d%d%d",&n,&m,&x,&y);
        for (int i = 1;i <= x;i ++)
          scanf("%d",&w1[i]);
        for (int i = 1;i <= y;i ++)
          scanf("%d",&w2[i]);
        for (int i = 1;i <= x;i ++)
          for (int j = n * m;j >= 2;j --)
            f[j] = Max(f[j],f[j - 2] + w1[i]);
        for (int i = 1;i <= y;i ++)
          for (int j = n * m;j >= 3;j --)
            f[j] = Max(f[j],f[j - 3] + w2[i]);
        printf("%d\n",f[n * m]);
    }
    return 0;
}
