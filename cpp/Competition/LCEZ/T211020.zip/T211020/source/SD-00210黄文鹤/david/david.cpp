#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<math.h>
#include<vector>
#include<bitset>
#include<queue>
#include<set>
#include<map>
#define ll long long
#define ld long double

inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const ll inf=1e18;
const ll maxn=50; 
ll n;
ll num[10];
char s[maxn];

int main(void)
{
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	n=read();
	scanf("%s",s+1);
	for(int i=1;i<=n;i++)
	{
		if(s[i]=='2'||s[i]=='3'||s[i]=='5'||s[i]=='7') num[s[i]-'0']++;
		else if(s[i]!='0'&&s[i]!='1')
		{
			if(s[i]=='9') num[7]++,num[2]++,num[3]+=2;
			if(s[i]=='4') num[3]++,num[2]+=2;
			if(s[i]=='6') num[5]++,num[3]++;
			if(s[i]=='8') num[7]++,num[2]+=3;
		}
	}
	for(int i=9;i>=2;i--)
	{
		for(int j=1;j<=num[i];j++) printf("%d",i);
	}
	return 0;
}


