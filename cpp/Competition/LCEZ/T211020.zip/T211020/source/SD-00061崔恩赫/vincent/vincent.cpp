#include<iostream>
#include<cstdio>
using namespace std;
#define N 2000005
int a[N],n;
int dp[61][N],ans=0;
int main()
{
  freopen("vincent.in","r",stdin);
  freopen("vincent.out","w",stdout);
  scanf("%d",&n);
  for(int i=1;i<=n;i++)
    scanf("%d",&a[i]);
  for(int i=1;i<=n;i++)
    dp[a[i]][i]=i+1;
  for(int i=2;i<=60;i++)
    for(int j=1;j<=n;j++)
    {
      if(!dp[i][j]) 
        dp[i][j]=dp[i-1][dp[i-1][j]];
      if(dp[i][j])  
        ans=i;
    }
  printf("%d",ans);
  return 0;
}
