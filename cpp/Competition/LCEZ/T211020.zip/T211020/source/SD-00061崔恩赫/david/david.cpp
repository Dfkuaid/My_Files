#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
int cnt[10];
int n;
char num[35];
vector<int> ans;
int main()
{
  freopen("david.in","r",stdin);
  freopen("david.out","w",stdout);
  scanf("%d",&n);
  scanf("%s",num+1);
  for(int i=1;i<=n;i++)
    for(int j=1;j<=num[i]-'0';j++)
      cnt[j]++;
  cnt[3]+=2*cnt[9];
  cnt[9]=0;
  cnt[2]+=cnt[8]*3;
  cnt[8]=0;
  cnt[2]+=cnt[6],cnt[3]+=cnt[6];
  cnt[6]=0;
  cnt[2]+=2*cnt[4];
  cnt[4]=0;
  for(int i=1;i<=cnt[7];i++)
  {
    ans.push_back(7);
    cnt[5]--;
    cnt[3]-=2;
    cnt[2]-=4;
  }
  for(int i=1;i<=cnt[5];i++)
  {
    ans.push_back(5);
    cnt[3]--;
    cnt[2]-=3;
  }
  for(int i=1;i<=cnt[3];i++)
  {
    ans.push_back(3);
    cnt[2]--;
  }
  for(int i=1;i<=cnt[2];i++)
    ans.push_back(2);
  for(int i=0;i<ans.size();i++)
    printf("%d",ans[i]);
  return 0;
} 
