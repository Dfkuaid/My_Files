#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
#define N 2005
int n,m;
char a[N][N];
bool kk[N];
int ans=0;
int main()
{
  freopen("evensgn.in","r",stdin);
  freopen("evensgn.out","w",stdout);
  scanf("%d%d",&n,&m);
  for(int i=1;i<=n;i++)
    scanf("%s",a[i]+1);
  for(int i=1;i<=m;i++)
  {
    bool add=0;
    for(int j=2;j<=n;j++)
      if(a[j][i]<a[j-1][i]&&(!kk[j]))
        add=1;
    ans+=add;
    if(add==0)
      for(int j=2;j<=n;j++)
        if(a[j-1][i]<a[j][i])
          kk[j]=1;
  }
  printf("%d",ans);
  return 0;
}
