#include<bits/stdc++.h>

using namespace std;

const long long maxN=1090;
vector<long long > spl[19];
long long nums[maxN];
vector<long long > res;
long long totN;
long long totM;
vector<long long > raw;

bool cmp(long long a,long long b) {
  return a>b;
}

int main() {
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
  scanf("%lld",&totN);
  getchar();
  for(int i=1,x; i<=totN; ++i) {
    x=getchar()-'0';
    raw.push_back(x);
  }
  spl[2].push_back(2);
  spl[3].push_back(3);
  spl[4].push_back(2);
  spl[4].push_back(2);
  spl[4].push_back(3);
  spl[5].push_back(5);
  spl[6].push_back(5);
  spl[6].push_back(3);
  spl[7].push_back(7);
  spl[8].push_back(7);
  spl[8].push_back(2);
  spl[8].push_back(2);
  spl[8].push_back(2);
  spl[8].push_back(2);
  spl[9].push_back(7);
  spl[9].push_back(2);
  spl[9].push_back(3);
  spl[9].push_back(3);
  for(auto i:raw) {
    for(auto j:spl[i]) {
      res.push_back(j);
    }
  }
  sort(res.begin(),res.end(),cmp);
  for(auto i:res) {
    printf("%lld",i);
  }
  return 0;
}