#include<bits/stdc++.h>
#define N 2500
using namespace std;
inline void read(int &x){
	x=0;int f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	x*=f;
}
char a[N][2500];
int sum=0;
int n,m;
int vis[N];
int ans=0;
inline void solve(int l,int r,int pos){
	if(pos==m+1)return ;
//	cerr<<l<<" "<<r<<" "<<pos<<"\n";
	for(int i=l+1;i<=r;i++){
		if(a[i][pos]<a[i-1][pos]) return solve(l,r,pos+1),vis[pos]=1,void();
	}
	for(int i=l+1,j=l;i<=r+1;i++){
		if(i==r+1?'\0':a[i][pos]==a[i-1][pos]) continue;
		else{
			if(j==i-1)continue;
			solve(j,i-1,pos+1),j=i;
		}
	}
}
int main(){
	freopen("evensgn.in","r",stdin);
	freopen("evensgn.out","w",stdout);
	read(n);read(m);
	if(n==1)cout<<0<<endl;
	for(int i=1;i<=n;i++){
		cin>>(a[i]+1);
	}
	solve(1,n,1);
	for(int i=1;i<=m;i++){
		ans+=vis[i];
	}
	cout<<ans<<endl;
	return 0;
}


/*
4 4
case
care
test
code

*/
