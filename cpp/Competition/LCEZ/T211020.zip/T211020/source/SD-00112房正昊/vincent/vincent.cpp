#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,ans;
ll x;
ll f[262145][62];
inline void read(ll &x){
	x=0;ll f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	x*=f;
}
int main()
{
	freopen("vincent.in","r",stdin);
	freopen("vincent.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)
	{
		read(x);
		f[i][x]=i+1;
	}
	for(int j=1;j<=61;j++){
		for(int i=1;i<=n;i++){
			if(!f[i][j])f[i][j]=f[f[i][j-1]][j-1];
			if(f[i][j])ans=j;
		}
	}
	cout<<ans<<endl;
	return 0;
}
