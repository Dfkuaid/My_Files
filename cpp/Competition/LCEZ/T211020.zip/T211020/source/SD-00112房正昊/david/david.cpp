#include<bits/stdc++.h>
#define  N 100010
#define ll long long
using namespace std;
inline void read(ll &x){
	x=0;ll f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	x*=f;
}
char ch;
ll a[N];
int main(){
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	ll n;
	read(n);
	for(int i=1;i<=n;i++){
		scanf("%c",&ch);	
		if(ch=='2')a[2]++;
		if(ch=='3')a[3]++,a[2]++;
		if(ch=='4')a[2]+=3,a[3]++;
		if(ch=='5')a[5]++,a[2]+=3,a[3]++;
		if(ch=='6')a[2]+=4,a[3]+=2,a[5]++;
		if(ch=='7')a[7]++,a[2]+=4,a[3]+=2,a[5]++;
		if(ch=='8')a[2]+=7,a[7]++,a[5]++,a[3]+=2;
		if(ch=='9')a[2]+=7,a[7]++,a[5]++,a[3]+=4;
	}
	while(a[7]){
		putchar('7');
		a[7]--,a[2]-=4,a[3]-=2,a[5]--;
	}
	while(a[5]){
		putchar('5');
		a[5]--,a[2]-=3,a[3]--;
	}
	while(a[3]){
		putchar('3');
		a[3]--,a[2]--;
	}
	while(a[2]){
		putchar('2');
		a[2]--;	
	}
	putchar('\n');
	return 0;
}


