#include<bits/stdc++.h>
#define ll long long
using namespace std;

inline ll read()
{
	ll x = 0, f = 0;
	char ch = getchar();
	while(!isdigit(ch)) f |= (ch == '-'), ch = getchar();
	while(isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^= 48), ch = getchar();
	return f ? -x : x;
}

void Wr(ll x)
{
	if(x < 0) putchar('-'), x = -x;
	if(x > 9) Wr(x / 10);
	putchar(x % 10 + 48);
}

void W(ll x, char ch)
{
	Wr(x);
	putchar(ch);
}

const ll N = 2003;
ll n ,m, ans;
char a[N][N];
int ok[N];

int main()
{
	freopen("evensgn.in", "r", stdin);
// freopen("evensgn3.in", "r", stdin);
	freopen("evensgn.out", "w", stdout);
// freopen("evensgn3.out", "w", stdout);

	n = read(), m = read();
	for(int i =1 ; i <= n; ++i)
		for(int j =1 ; j <= m; ++j)
			cin >> a[i][j];

	for(int j = 1; j <= m; ++j)
	{
		bool thisok = 1;
		for(int i = 1; i < n; ++i)
		{
			if(ok[i]) continue;
			if(a[i][j] < a[i + 1][j]) ok[i] = 1;
			else if(a[i][j] > a[i + 1][j])
			{
				thisok = 0;
				break;
			}
		}

		if(thisok == 0)
		{
			++ans;
			for(int i = 1; i <= n; ++i)
				if(ok[i] == 1)
					ok[i] = 0;
		}

		for(int i = 1; i <= n; ++i)
			if(ok[i] == 1)
				ok[i] = 2;
	}

	W(ans, '\n');
	return 0;
}

/*

4 4
case
care
test
code

5 4
code
forc
esco
defo
rces
*/

