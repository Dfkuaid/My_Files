#include<bits/stdc++.h>
#define ll long long
using namespace std;
void Wr(ll x)
{
   if(x < 0) putchar('-'), x = -x;
   if(x > 9) Wr(x / 10);
   putchar(x % 10 + 48);
}

ll tong[10];

int main()
{
   freopen("david.in", "r", stdin);
 //freopen("david3.in", "r", stdin); 
   freopen("david.out", "w", stdout);   
   ll n;
   cin >> n;
   for(int i =1; i <= n; ++i)
   {
      char ch;
      cin >> ch;
      int x = (ch - '0');
      if(x == 1);
      if(x == 2) ++tong[2];
      if(x == 3) ++tong[3];
      if(x == 4) ++tong[3], tong[2] += 2;
      if(x == 5) ++tong[5];
      if(x == 6) ++tong[5], ++tong[3];
      if(x == 7) ++tong[7];
      if(x == 8) ++tong[7], tong[2] += 3;
      if(x == 9) ++tong[7], tong[3] += 2, ++tong[2]; 
   }
   for(int i =9; i >= 2; --i)
      for(int j = 1; j <= tong[i]; ++j)
         Wr(i);
   putchar('\n');
   return 0;
}
/*
1       
2        2
6        3
24       3, 2, 2
120      5
720      5, 3
5040     7
40320    7, 2, 2, 2
362880   7, 3, 3, 2
*/
// 

