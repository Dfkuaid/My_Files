#include<bits/stdc++.h>
#define ll long long
using namespace std;

inline ll read()
{
   ll x = 0, f = 0;
   char ch = getchar();
   while(!isdigit(ch)) f |= (ch == '-'), ch = getchar();
   while(isdigit(ch)) x = (x << 1) + (x << 3) + (ch ^= 48), ch = getchar();
   return f ? -x : x; 
}

void Wr(ll x)
{
   if(x < 0) putchar('-'), x = -x;
   if(x > 9) Wr(x / 10);
   putchar(x % 10 + 48);
}

void W(ll x, char ch)
{
   Wr(x);
   putchar(ch);
}

const ll N = 2000005;
int n, a[N], st[N], top, ans;

int main()
{
   freopen("vincent.in", "r", stdin);
   freopen("vincent.out", "w", stdout);   
   n = read();
   for(int i =1; i <= n; ++i)
      a[i] = read();
   
   for(int i = 1; i <= n; ++i)
   {
      st[++top] = a[i];
      while(st[top] == st[top - 1])
      {
         --top;
         ++st[top];
      }
      ans = max(st[top], ans);
   }
   
      
   top = 0;
   for(int i = n; i >= 1; --i)
   {
      st[++top] = a[i];
      while(st[top] == st[top - 1])
      {
         --top;
         ++st[top];
      }
      ans = max(st[top], ans);
   }
   
   W(ans, '\n');
  
   return 0;
}



