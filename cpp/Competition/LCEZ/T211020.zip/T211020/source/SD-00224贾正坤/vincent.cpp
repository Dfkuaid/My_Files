#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int rd(){
	int res = 0, fl = 1; char c = getchar();
    while(!isdigit(c)){if(c == '-') fl = -1; c = getchar();}
    while(isdigit(c)){res = (res << 3) + (res << 1) + c - '0'; c = getchar();}
    return res * fl;
} 
int n, a[2000010];
namespace On3{
int ans, f[110][110];
int main(){
	for(int i(1);i<=n;++i){
		f[i][i]=a[i];
		ans=max(ans, a[i]);
	}
	for(int len(2);len<=n;++len){
		for(int i(1);i<=n-len+1;++i){
			int j(i+len-1);
			f[i][j]=-1;
			for(int k(i);k<j;++k){
				if(f[i][k]==f[k+1][j]){
					f[i][j]=f[i][k]+1;
					ans=max(ans, f[i][j]);
					break; 
				}
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
}
namespace a1{
int main(){
	printf("%d\n", log2(n));
	return 0;
}
}
namespace Inca{
int ans, num, lst, cnt[2000010];
int main(){
	for(int i(1);i<=n;++i){
		if(a[i]!=a[i+1]){
			cnt[a[i]]=i-lst;
			lst=i;
		}
	}
	for(int i(1);i<=a[n];++i){
		if(!cnt[i]) continue;
		ans=max(ans, i);
		cnt[i+1]+=cnt[i]/2;
	}
	printf("%d\n", ans);
}
}
namespace Db{
int dp[2000010][70], lg2[2000010], ans;
int main(){
	memset(dp, -1, sizeof(dp));
	lg2[0]=-1;
	for(int i(1);i<=n;++i) lg2[i]=lg2[i/2]+1;
	for(int i(1);i<=n;++i){
		dp[i][a[i]]=i;
	}
	for(int j(1);j<=61;++j){
		for(int i(1);i<=n;++i){
			if(dp[i][j-1]!=-1) dp[i][j]=dp[dp[i][j-1]+1][j-1];
			if(dp[i][j]!=-1){
//				printf("dp[%d][%d]=%d\n", i, j, dp[i][j]);
				ans=max(ans, j);
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
}
int main(){
	freopen("vincent.in", "r", stdin);
	freopen("vincent.out", "w", stdout);
	n=rd();
	for(int i(1);i<=n;++i){
		a[i]=rd();
	}
	Db::main();
	return 0;
}
