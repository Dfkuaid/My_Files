#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int rd(){
	int res = 0, fl = 1; char c = getchar();
    while(!isdigit(c)){if(c == '-') fl = -1; c = getchar();}
    while(isdigit(c)){res = (res << 3) + (res << 1) + c - '0'; c = getchar();}
    return res * fl;
}
int n, m, ans, sme[2010];
char str[2010][2010];
bool cal(int p){
	for(int i(2);i<=n;++i){
		if((!sme[i-1])&&str[i-1][p]>str[i][p]){
			return 0;
		}
	}
	for(int i(1);i<n;++i){
		if(str[i][p]<str[i+1][p]) sme[i]=1;
	}
	return 1;
}
int main(){
	freopen("evensgn.in", "r", stdin);
	freopen("evensgn.out", "w", stdout);
	
	n=rd(), m=rd();
	for(int i(1);i<=n;++i){
		cin>>(str[i]+1);
	}
//	for(int i(1);i<=n;++i){
//		for(int j(1);j<=m;++j) printf("%c ", str[i][j]); printf("\n");
//	} 
	for(int i(1);i<=m;++i){
		if(cal(i)){
//			printf("%d is ok\n", i);
//			for(int j(1);j<=n;++j) printf("%d ", sme[j]); printf("\n");
			ans++;
		}
	}
	printf("%d\n", m-ans);
	return 0;
}
/*
1 10
orzevensgn

4 4
case
care
test
code

5 4
code
forc
esco
defo
rces


*/
