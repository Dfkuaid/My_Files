#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int rd(){
	int res = 0, fl = 1; char c = getchar();
    while(!isdigit(c)){if(c == '-') fl = -1; c = getchar();}
    while(isdigit(c)){res = (res << 3) + (res << 1) + c - '0'; c = getchar();}
    return res * fl;
}
const int maxn = 1000010;
int n, cnt[11], ans[11], a;
char c;
void cal(int x){
	printf("cal %d\n", x);
	if(x==2) cnt[2]++;
	if(x==3) cnt[3]++;
	if(x==4) cnt[2]+=2;
	if(x==5) cnt[5]++;
	if(x==6) cnt[2]++, cnt[3]++;
	if(x==7) cnt[7]++;
	if(x==8) cnt[2]+=3;
	if(x==9) cnt[3]+=2;
	return;
}
int main(){
	freopen("david.in", "r", stdin);
	freopen("david.out", "w", stdout);
	n=rd();
	for(int i(1);i<=n;++i){
		c=getchar();
		while(!isdigit(c)){
			c=getchar();
		}
		a=c-'0';
		if(a==5) ans[5]++;
		else if(a==7) ans[7]++; 
		else for(int j(a);j;j--){
			if(j==3){
				ans[3]++; break;
			}
			if(j==5){
				ans[5]++; break;
			}
			if(j==7){
				ans[7]++; break;
			}
			cal(j);
		}
	}
	for(int i(1);i<=ans[7];++i) printf("7");
	for(int i(1);i<=ans[5];++i) printf("5");
	for(int i(1);i<=ans[3];++i) printf("3");
	for(int i(1);i<=cnt[3];++i) printf("3");
	for(int i(1);i<=cnt[2];++i) printf("2");
	printf("\n");
//	5---5
//	7---7
	return 0;
}

