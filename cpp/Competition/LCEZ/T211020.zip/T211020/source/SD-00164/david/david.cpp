#include<bits/stdtr1c++.h>

namespace zhang_tao{
  inline int read(int &x){
    x=0;int fh=1;
    char ch=getchar();
    while(!isdigit(ch)){
      if(ch=='-')
        fh=-1;
      ch=getchar();
    }
    while(isdigit(ch)){
      x=x*10+ch-'0';
      ch=getchar();
    }
    return x*=fh;
  }
  inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10+48);
  }
  inline int _gcd(const int x,const int y){
    return y?_gcd(y,x%y):x;
  }
  inline void _swap(int &x,int &y){
    x^=y^=x^=y;
  }
} // namespace zhang_tao

using namespace zhang_tao;
const int maxn=35;

int n;
char num[maxn];
std::vector<int>ans;

signed main(){
  freopen("david.in","r",stdin);
  freopen("david.out","w",stdout);
  read(n);
  scanf("%s",num+1);
  for(int i=1;i<=n;++i){
    int p=num[i]-'0';
    if(p==0 || p==1) continue;
    if(p==2) ans.push_back(2);
    if(p==3) ans.push_back(3);
    if(p==4){
      ans.push_back(3);
      for(int i=1;i<=2;++i)
        ans.push_back(2);
    }
    if(p==5) ans.push_back(5);
    if(p==6) ans.push_back(5),ans.push_back(3);
    if(p==7) ans.push_back(7);
    if(p==8){
      ans.push_back(7);
      for(int i=1;i<=3;++i)
        ans.push_back(2);
    }
    if(p==9) ans.push_back(7),ans.push_back(3),ans.push_back(3),ans.push_back(2);
  }
  std::sort(ans.begin(),ans.end());
  for(int i=ans.size()-1;i>=0;--i)
    write(ans[i]);
  return 0;
}
