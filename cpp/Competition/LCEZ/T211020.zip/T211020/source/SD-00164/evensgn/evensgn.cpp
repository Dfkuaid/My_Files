#include<bits/stdtr1c++.h>

namespace zhang_tao{
  inline int read(int &x){
    x=0;int fh=1;
    char ch=getchar();
    while(!isdigit(ch)){
      if(ch=='-')
        fh=-1;
      ch=getchar();
    }
    while(isdigit(ch)){
      x=x*10+ch-'0';
      ch=getchar();
    }
    return x*=fh;
  }
  inline void write(int x){
    if(x<0) putchar('-'),x=-x;
    if(x>9) write(x/10);
    putchar(x%10+48);
  }
  inline int _gcd(const int x,const int y){
    return y?_gcd(y,x%y):x;
  }
  inline void _swap(int &x,int &y){
    x^=y^=x^=y;
  }
} // namespace zhang_tao

using namespace zhang_tao;
const int maxn=2005;

int n,m,ans;
int del[maxn]; 
char ch[maxn][maxn];

void work(const int l,const int r,int line){
  if(line==m+1) return;
  if(del[line]){
    work(l,r,line+1);
    return;
  }
  int flag=2,num=ch[l][line];
  for(int i=l+1;i<=r;++i){
    int p=ch[i][line];
    if(p<num){
      flag=0;
      break;
    }else if(num==p){
      flag=1;
    }else num=p;
  }
  if(flag==2) return;//���㵥������ 
  else if(flag==1){//����
    int now=0,L=1,R=1;
    for(int i=l;i<=r;++i){
      if(ch[i][line]!=now && R-L>=1){
        work(L,R,line+1);
        L=R=i;
      }else R++;
    }
    return;
  }else{
    del[line]=1,ans++;
    work(l,r,line+1);
  }
}

signed main(){
  freopen("evensgn.in","r",stdin);
  freopen("evensgn.out","w",stdout);
  read(n),read(m);
  for(int i=1;i<=n;++i) scanf("%s",ch[i]+1);
  work(1,n,1);
  write(ans),putchar('\n');
  return 0;
}
