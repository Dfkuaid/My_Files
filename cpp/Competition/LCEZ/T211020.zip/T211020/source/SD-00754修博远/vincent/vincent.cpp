#include<iostream>
#include<cstdio>
#define maxn 264145

using namespace std;
int n,f[62][maxn],t,ans;

template<typename type>
inline void read(type &x)
{
	x=0;bool flag(0);char ch=getchar();
	while(!isdigit(ch)) flag^=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	flag?x=-x:0;
}

template<typename type>
inline void write(type x,bool mode)
{
	x<0?x=-x,putchar('-'):0;static short Stack[50],top(0);
	do Stack[++top]=x%10,x/=10;while(x);
	while(top) putchar(Stack[top--]|48);
	mode?putchar('\n'):putchar(' ');
}

signed main()
{
	freopen("vincent.in","r",stdin);
	freopen("vincent.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) read(t),f[t][i]=i+1;
	for(int i=1;i<=61;i++)
		for(int j=1;j<=n;j++)
		{
			if(!f[i][j]) f[i][j]=f[i-1][f[i-1][j]];
			if(f[i][j]) ans=i;
		}
	write(ans,1);
	return 0;
}
