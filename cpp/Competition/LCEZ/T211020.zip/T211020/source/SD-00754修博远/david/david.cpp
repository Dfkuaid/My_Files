#include<iostream>
#include<cstdio>

using namespace std;

int n,a[20];
char ch;

template<typename type>
inline void read(type &x)
{
	x=0;bool flag(0);char ch=getchar();
	while(!isdigit(ch)) flag^=ch=='-',ch=getchar();
	while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	flag?x=-x:0;
}

template<typename type>
inline void write(type x,bool mode)
{
	x<0?x=-x,putchar('-'):0;static short Stack[50],top(0);
	do Stack[++top]=x%10,x/=10;while(x);
	while(top) putchar(Stack[top--]|48);
	mode?putchar('\n'):putchar(' ');
}

signed main()
{
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	read(n);
//	scanf("%c",&ch);
	for(int i=1;i<=n;i++)
	{
		scanf("%c",&ch);
		switch(ch)
		{
			case 50:a[2]++;break;//2!=2
			case 51:a[2]++,a[3]++;break;//3!=(2*1)*(3*1)
			case 52:a[2]+=3,a[3]++;break;//4!=(2*3)*(3*1)
			case 53:a[2]+=3,a[3]++,a[5]++;break;//5!=(2*3)*(3*1)*(5*1)
			case 54:a[2]+=4,a[3]+=2,a[5]++;break;//6!=(2*4)*(3*2)*(5*1)
			case 55:a[2]+=4,a[3]+=2,a[5]++,a[7]++;break;//7!=(2*4)*(3*2)*(5*1)*(7*1)
			case 56:a[2]+=7,a[3]+=2,a[5]++,a[7]++;break;//8!=(2*7)*(3*2)*(5*1)*(7*1)
			case 57:a[2]+=7,a[3]+=4,a[5]++,a[7]++;break;//9!=(2*7)*(3*4)*(5*1)*(7*1)
			default:break;
		}
	}
//	while(a[2]>=7&&a[3]>=4&&a[5]&&a[7]) a[2]-=7,a[3]-=4,a[5]--,a[7]--,putchar('9');
//	while(a[2]>=7&&a[3]>=2&&a[5]&&a[7]) a[2]-=7,a[3]-=2,a[5]--,a[7]--,putchar('8');
	while(a[2]>=4&&a[3]>=2&&a[5]&&a[7]) a[2]-=4,a[3]-=2,a[5]--,a[7]--,putchar('7');
//	while(a[2]>=4&&a[3]>=2&&a[5]) a[2]-=4,a[3]-=2,a[5]--,putchar('6');
	while(a[2]>=3&&a[3]&&a[5]) a[2]-=3,a[3]--,a[5]--,putchar('5');
//	while(a[2]>=3&&a[3]) a[2]-=3,a[3]--,putchar('4');
	while(a[2]&&a[3]) a[2]--,a[3]--,putchar('3');
	while(a[2]) a[2]--,putchar('2');
	return 0;
}
