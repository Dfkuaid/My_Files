#include <bits/stdc++.h>

#define LL long long
#define CI const int
#define I inline
#define Heriko return
#define Deltana 0

using namespace std;

CI MXX(31);

template<typename J>
I void fr(J &x)
{
	x=0;short f(1);char c(getchar());
	
	while(c<'0' or c>'9')
	{
		if(c=='-') f=-1;
		
		c=getchar();
	}
	
	while(c>='0' and c<='9')
	{
		x=(x<<3)+(x<<1)+(c^=48);
		c=getchar();
	}
	
	x*=f;
}

int n,co[15];

char a[MXX];

signed main()
{
	//freopen("julian3.in","r",stdin);
	//freopen("david3.in","r",stdin);
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	
	fr(n);scanf("%s",a+1);
	
	for(int i(1);i<=n;++i)
	{
		if(a[i]=='2') ++co[2];
		else if(a[i]=='3') ++co[3];
		else if(a[i]=='4') co[2]+=2,++co[3];//4 -> 1 * 2 * 3 * 4 = 1 * 2 * 3 * 2 * 2 = 2! * 2! * 3!
		else if(a[i]=='5') ++co[5];
		else if(a[i]=='6') ++co[3],++co[5];//6 -> 2^4 * 3^2 * 5^1 = 2 * 3 * 2 * 3 * 4 * 5 = 3! * 5!
		else if(a[i]=='7') ++co[7];
		else if(a[i]=='8') co[2]+=3,++co[7];//8 -> 2^3 * 3^0 * 5^0 * 7^0 = 2 * 3 * (2 * 2) * 5 * (2 * 3) * 7
		else if(a[i]=='9') ++co[2],co[3]+=2,++co[7];//9 -> 2^0 * 3^0 * 5^0 * 7^0 = 7! * 3! * 3! * 2!
	}
	
	for(int i(9);i;--i)
		if(co[i])
			while(co[i]--)
				printf("%d",i);
	
	Heriko Deltana;
}

