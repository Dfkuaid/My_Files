#include <bits/stdc++.h>

#define LL long long
#define CI const int
#define I inline
#define Heriko return
#define Deltana 0

using namespace std;

template<typename J>
I void fr(J &x)
{
	x=0;short f(1);char c(getchar());
	
	while(c<'0' or c>'9')
	{
		if(c=='-') f=-1;
		
		c=getchar();
	}
	
	while(c>='0' and c<='9')
	{
		x=(x<<3)+(x<<1)+(c^=48);
		c=getchar();
	}
	
	x*=f;
}

CI MXX(2001);

int n,m,ans,lst[MXX],nw[MXX];

char s[MXX][MXX];

signed main()
{
	//freopen("julian3.in","r",stdin);
	//freopen("evensgn3.in","r",stdin);
	freopen("evensgn.in","r",stdin);
	freopen("evensgn.out","w",stdout);
	
	fr(n),fr(m);
	
	if(n==1)
	{
		puts("0");
		
		Heriko Deltana;
	}
	
	for(int i(1);i<=n;++i) scanf("%s",s[i]+1);
	
	for(int i(1);i<=m;++i)
	{
		int del(0);
		nw[1]=0;
		
		for(int j(1);j<n;++j)
		{
			if(lst[j]>=lst[j+1])
			{
				if(s[j][i]>s[j+1][i]) {++ans;del=1;break;}
				else if(s[j][i]<s[j+1][i]) nw[j+1]=nw[j]+1;
				else nw[j+1]=nw[j];
			}
			else if(lst[j]<lst[j+1]) nw[j+1]=nw[j]+1;
		}
		
		if(!del)
			for(int j(1);j<=n;++j)
				lst[j]=nw[j];
	}
	
	printf("%d\n",ans);
	
	Heriko Deltana;	
}
