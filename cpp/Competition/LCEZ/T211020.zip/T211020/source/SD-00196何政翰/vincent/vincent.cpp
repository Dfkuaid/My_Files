#include <bits/stdc++.h>

#define LL long long
#define CI const int
#define I inline
#define Heriko return
#define Deltana 0

using namespace std;

template<typename J>
I void fr(J &x)
{
	x=0;short f(1);char c(getchar());
	
	while(c<'0' or c>'9')
	{
		if(c=='-') f=-1;
		
		c=getchar();
	}
	
	while(c>='0' and c<='9')
	{
		x=(x<<3)+(x<<1)+(c^=48);
		c=getchar();
	}
	
	x*=f;
}

template<typename J>
I J Hmax(const J &x,const J &y) {Heriko x>y?x:y;}

CI MXX(101);

int n,f[MXX][MXX],ans;

signed main()
{
	//freopen("julian3.in","r",stdin);
	//freopen("vincent3.in","r",stdin);
	freopen("vincent.in","r",stdin);
	freopen("vincent.out","w",stdout);
	
	fr(n);
	
	for(int i(1);i<=n;++i) fr(f[i][i]);
	
	for(int len(2);len<=n;++len)
		for(int l(1),r=l+len-1;r<=n;++l,++r)
		{
			f[l][r]=-1;
			
			for(int k(l);k<r;++k)
				if(~f[l][k] and ~f[k+1][r] and f[l][k]==f[k+1][r])
					f[l][r]=Hmax(f[l][r],f[l][k]+1);
			ans=Hmax(ans,f[l][r]);
		}
			
	printf("%d\n",ans);
	
	Heriko Deltana;
}

