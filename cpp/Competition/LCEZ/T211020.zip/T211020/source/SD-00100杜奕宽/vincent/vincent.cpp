#include <bits/stdc++.h>
using namespace std;

const int N = 110;

int n, a[N], f[N][N], ans;

int main() {
    freopen("vincent.in", "r", stdin);
    freopen("vincent.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i <= n; ++ i)
      scanf("%d", &a[i]), ans = max(ans, a[i]);
    for (int i = 1; i <= n; ++ i) f[i][i] = a[i];
    for (int i = 2; i <= n; ++ i)
      for (int l = 1, r = l + i - 1; r <= n; ++ l, ++ r) {
          f[l][r] = -1;
          for (int k = l; k < r; ++ k)
            if (~f[l][k] && ~f[k + 1][r] && f[l][k] == f[k + 1][r])
              f[l][r] = max(f[l][r], f[l][k] + 1);
          ans = max(ans, f[l][r]);
      }
    printf("%d", ans); return 0;
}