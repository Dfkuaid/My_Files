#include <bits/stdc++.h>
#define mset(l, x) memset(l, x, sizeof(l))
using namespace std;

const int N = 2010;

template <typename T> inline void read(T &x) {
    x = 0; int f = 1; char c = getchar();
    for (; !isdigit(c); c = getchar()) if (c == '-') f = -f;
    for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
    x *= f;
}

template <typename T> inline T Min(T a, T b) {return a < b ? a : b;}

int n, m, a[N][N], ans, tag[N], tmp[N]; char s[N];

int main() {
    freopen("evensgn.in", "r", stdin);
    freopen("evensgn.out", "w", stdout);
    read(n), read(m);
    for (int i = 1;  i <= n; ++ i) {
        scanf("%s", s + 1);
        for (int j = 1; j <= m; ++ j)
          a[i][j] = s[j] - 'a';
    }
    tmp[1] = 1;
    for (int i = 1; i <= m; ++ i) {
        int flag = 0;
        for (int j = 2; j <= n; ++ j)
          if (tag[j] > tag[j - 1]) tmp[j] = tmp[j - 1] + 1;
          else if (tag[j] == tag[j - 1] && a[j][i] > a[j - 1][i])
            tmp[j] = tmp[j - 1] + 1;
          else if (tag[j] == tag[j - 1] && a[j][i] == a[j - 1][i])
            tmp[j] = tmp[j - 1];
          else if (tag[j] == tag[j - 1] && a[j][i] < a[j - 1][i]) {
              ++ ans; flag = 1; break;
          }
        if (flag) continue;
        for (int i = 1; i <= n; ++ i) tag[i] = tmp[i];
    }
    printf("%d", ans); return 0;
}