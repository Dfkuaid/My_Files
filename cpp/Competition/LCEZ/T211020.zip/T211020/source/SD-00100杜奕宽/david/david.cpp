#include <bits/stdc++.h>
using namespace std;

const int N = 1010;

template <typename T> inline void read(T &x) {
    x = 0; int f = 1; char c = getchar();
    for (; !isdigit(c); c = getchar()) if (c == '-') f = -f;
    for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
    x *= f;
}

int n, a[N], cnt;

inline bool cmp(int x, int y) {return x > y;}

int main() {
    freopen("david.in", "r", stdin);
    freopen("david.out", "w", stdout);
    read(n); char c; int x = 0;
    for (int i = 1; i <= n; ++ i) {
        cin >> c; x = c - '0';
        if (x == 0 || x == 1) continue;
        else if (x == 2 || x == 3 || x == 5 || x == 7) a[++ cnt] = x;
        else if (x == 4) a[++ cnt] = 2, a[++ cnt] = 2, a[++ cnt] = 3;
        else if (x == 6) a[++ cnt] = 3, a[++ cnt] = 5;
        else if (x == 8) a[++ cnt] = 2, a[++ cnt] = 2, a[++ cnt] = 2, a[++ cnt] = 7;
        else if (x == 9) a[++ cnt] = 2, a[++ cnt] = 3, a[++ cnt] = 3, a[++ cnt] = 7;
    }
    sort(a + 1, a + cnt + 1, cmp);
    for (int i = 1; i <= cnt; ++ i) putchar(a[i] + '0');
    return 0;
}