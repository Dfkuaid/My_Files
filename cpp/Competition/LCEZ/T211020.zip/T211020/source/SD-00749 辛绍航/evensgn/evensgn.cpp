#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int ans,n,m,t;
char a[2001][2001],cmp1[2001],cmp2[2001];
bool ok[2001];
int main(){
	freopen("evensgn.in","r",stdin);
	freopen("evensgn.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		cin>>a[i]+1;
	}
	for(int i=1;i<=m;i++){
		int t=1;
		for(int j=2;j<=n;j++){
			for(int k=1;k<=i;k++){
				if(a[j-1][k]>a[j][k]){
					j=n+1;
					k=m+1;
					t=0;
				}
				if(a[j-1][k]<a[j][k]){
					k=m+1;
				}
			}
		}
		if(!t){
			ans++;
			for(int j=1;j<=n;j++){
				a[j][i]='a';
			}
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4 4
case
care
test
code

�������� 1

1 10
orzevensgn

������� 1
0
�������� 2

4 4
case
care
test
code

������� 2
2

cctc
aaeo
srsd
eete

aaeo
eete

ae
ae
et
oe
___________________________
�������� 3

5 4
code
forc
esco
defo
rces

������� 3
4

*/
