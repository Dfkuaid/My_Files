#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int n,a,ans[101],num[10];
int main(){
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	scanf("%d",&n);
	for(int j=1;j<=n;++j){
		scanf("%1d",&a);
		for(int i=2;i<=a;++i)
		if(i==4){
			num[2]+=2;
		}
		else if(i==6){
			num[2]++;
			num[3]++;
			
		}
		else if(i==8){
			num[2]+=3;
		}
		else if(i==9){
			num[3]+=2;
		}
		else{
			num[i]++;
		}
	}
	for(int i=7;i>=2;i--){
		if(num[i]>0){
			if(i==7){
				num[2]-=num[i]*4;
				num[3]-=num[i]*2;
				num[5]-=num[i];
				while(num[7]--){
					printf("7");
				}
			}
			else if(i==5){
				num[2]-=num[i]*3;
				num[3]-=num[i];
				while(num[5]--){
					printf("5");
				}
			}
			else if(i==3){
				num[2]-=num[i];
				while(num[3]--){
					printf("3");
				}
			}
			else if(i==2){
				while(num[2]--){
					printf("2");
				}
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4
1234

29
99999999999999999999999999999
*/
