#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int ans,n,a[2000001],a1,f[10001][10001],dd;
int dfs(int l,int r){
	if(l==r){
		f[l][r]=a[l];
		return a[l];
	}
	if(f[l][r]>0){
		return f[l][r];
	}
	int maxx=0;
	for(int i=l;i<r;i++){
		int L=dfs(l,i),R=dfs(i+1,r);
		//cout<<L<<" "<<R<<endl;
		if(L==R&&L>0){
			maxx=max(maxx,L+1);
		}
	}
	if(maxx>0){
		f[l][r]=maxx;
		return maxx;
	}
	else{
		f[l][r]=-1;
		return -1;
	}
}
int main(){
	freopen("vincent.in","r",stdin);
	freopen("vincent.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(a[i]!=1){
			a1=1;
		}
		if(a[i]<a[i-1]){
			dd=1;
		}
	}
	if(!a1){
		cout<<log2(n)+1;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
//	if(!dd){
//		for(int i=2;i<=n;i++){
//			if(a[i]==a[i-1]){
//				a[i]++;
//			}
//		}
//		cout<<a[n];
//		fclose(stdin);
//		fclose(stdout);
//		return 0;
//	}
	//cout<<dfs(2,2);
	dfs(1,n);
//	for(int i=1;i<=n;i++){
//		for(int j=i+1;j<=n;j++){
//			cout<<"i:"<<i<<" j:"<<j<<" f:"<<f[i][j]<<'\n';
//		}
//	}
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			ans=max(ans,f[i][j]);
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
4
1 1 1 2

6
1 1 2 3 4 5
*/
