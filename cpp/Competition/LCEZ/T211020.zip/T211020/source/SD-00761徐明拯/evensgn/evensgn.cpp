#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2005;
int n,m,ans;
char s[N][N];
vector< pair<int,int> > ask,Wit;
void calc(int pos){
	int flg=0;
	Wit.clear();
	for(int i=0;i<ask.size();i++){
		if(flg==2) break;
		int l=ask[i].first,r=ask[i].second;
		for(int j=l,k;j<=r;j=k){
			k=j+1;
			while(s[k][pos]==s[k-1][pos]&&k<=r) k++;
			if(k>j+1){
				flg=1;
				Wit.push_back(make_pair(j,k-1));
			}
		}
		for(int j=l;j<r;j++){
			if(s[j][pos]>s[j+1][pos]){
				flg=2;
				break;
			}
		}
	}
	
	if(flg==0){
		printf("%d\n",ans);
		exit(0);
	}
	
	if(flg==1){
		ask.clear();
		for(int i=0;i<Wit.size();i++){
			int l=Wit[i].first,r=Wit[i].second;
			ask.push_back(make_pair(l,r));
		}
	}
	
	if(flg==2){
		ans++;
		Wit.clear();
	}
	
}
int main()
{
	freopen("evensgn.in","r",stdin);
	freopen("evensgn.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>s[i][j];
		}
	}
	
	ask.push_back(make_pair(1,n));
	
	for(int j=1;j<=m;j++){
		calc(j);
	}
	printf("%d\n",ans);
	
	return 0;
}
/*
4 4
case
care
test
code
*/

