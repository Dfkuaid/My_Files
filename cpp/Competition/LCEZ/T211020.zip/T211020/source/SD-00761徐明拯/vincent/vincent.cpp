#include<bits/stdc++.h>
#define ll long long
#define ri register int
using namespace std;
const int N=2e6+5;
int n;
int a[N],f[62][N];
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-1;ch=getchar();}
	while(isdigit(ch)){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("vincent.in","r",stdin);
	freopen("vincent.out","w",stdout);
	n=read();
	for(ri i(1);i<=n;++i){
		a[i]=read();
		f[a[i]][i]=i;
	}
	
	for(ri i(1);i<=60;++i){
		for(ri j(1);j<=n;++j){
			if(f[i-1][f[i-1][j]+1]&&f[i-1][j]){
				f[i][j]=f[i-1][f[i-1][j]+1];
			}
		}
	}
	
	for(ri i(60);i>=1;--i){
		for(ri j(1);j<=n;++j){
			if(f[i][j]){
				printf("%d\n",i);
				return 0;
			}
		}
	}
	
	return 0;
}

