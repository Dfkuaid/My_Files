#include<bits/stdc++.h>
#define ll long long
#define pb push_back
using namespace std;
const int N=1e6+5;
int n;
char s[N];
vector<int> ans;
bool cmp(int a,int b){
	return a>b;
}
int main()
{
	freopen("david.in","r",stdin);
	freopen("david.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<=n;i++){
		if(s[i]=='0'||s[i]=='1') continue;
		if(s[i]=='2') ans.pb(2);
		if(s[i]=='3') ans.pb(3);
		if(s[i]=='4'){
			ans.pb(3);
			ans.pb(2);
			ans.pb(2);
		}
		if(s[i]=='5') ans.pb(5);
		if(s[i]=='6'){
			ans.pb(5);
			ans.pb(3);
		}
		if(s[i]=='7') ans.pb(7);
		if(s[i]=='8'){
			ans.pb(7);
			ans.pb(2);
			ans.pb(2);
			ans.pb(2);
		}
		if(s[i]=='9'){
			ans.pb(7);
			ans.pb(3);
			ans.pb(3);
			ans.pb(2);
		}
	}
	
	sort(ans.begin(),ans.end(),cmp);
	
	for(int i=0;i<ans.size();i++){
		printf("%d",ans[i]);
	}
	
	return 0;
}

