#include<bits/stdc++.h>
#define LL long long
#define dv double
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define pub push_back
#define pii pair<int,int>
#define mkp make_pair
#define x first
#define y second
#define KafuuChino return
#define HotoKokoa 0;
using namespace std;
il void Read(int &x){
  int f=1;x=0;char c=getchar();
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(x<<3)+(x<<1)+c-'0',c=getchar();
  }
  x*=f;
}
int n;char a[35];int s[35];
int cnt[10];
int main(){
  //freopen("julian3.in","r",stdin);
  freopen("david.in","r",stdin);
  freopen("david.out","w",stdout);
  Read(n),scanf("%s",a+1);
  for(rg int i=1;i<=n;i++){
    int t=1;
    for(rg int j=1;j<=a[i]-48;j++)t*=j;
    s[i]=t;
  }
  for(rg int i=1;i<=n;i++){
    while(s[i]%2==0)s[i]/=2,cnt[2]++;
    while(s[i]%3==0)s[i]/=3,cnt[3]++;
    while(s[i]%5==0)s[i]/=5,cnt[5]++;
    while(s[i]%7==0)s[i]/=7,cnt[7]++;
  }
  while(cnt[7]--){
    putchar('7'),cnt[2]-=4,cnt[3]-=2,cnt[5]--;
  }
  while(cnt[5]--){
    putchar('5'),cnt[2]-=3,cnt[3]--;
  }
  while(cnt[3]--){
    putchar('3'),cnt[2]--;
  }
  while(cnt[2]--)putchar('2');
  puts("");
  KafuuChino HotoKokoa
}
