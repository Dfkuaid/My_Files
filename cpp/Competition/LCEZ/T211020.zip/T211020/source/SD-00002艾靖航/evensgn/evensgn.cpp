#include<bits/stdc++.h>
#define LL long long
#define dv double
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define pub push_back
#define pii pair<int,int>
#define mkp make_pair
#define x first
#define y second
#define KafuuChino return
#define HotoKokoa 0;
using namespace std;
il void Read(int &x){
  int f=1;x=0;char c=getchar();
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(x<<3)+(x<<1)+c-'0',c=getchar();
  }
  x*=f;
}
const int N=2010;
int n,m;char a[N][N];
int vis[N];//row i and row i+1
int main(){
  //freopen("julian3.in","r",stdin);
  freopen("evensgn.in","r",stdin);
  freopen("evensgn.out","w",stdout);
  Read(n),Read(m);
  for(rg int i=1;i<=n;i++)scanf("%s",a[i]+1);
  for(rg int i=1;i<=n;i++)a[i][0]=0;
  int ans=0;
  for(rg int j=1;j<=m;j++){
    bool ff=0;
    for(rg int i=1;i<n;i++){
      if(vis[i])continue;
      if(a[i][j]<a[i+1][j])vis[i]=2;
      else if(a[i][j]>a[i+1][j]){
        ff=1;break;
      }
    }
    if(ff){
      for(rg int i=1;i<=n;i++)if(vis[i]==2)vis[i]=0;
      ans++;
    }
    for(rg int i=1;i<=n;i++)if(vis[i]==2)vis[i]=1;
  }
  printf("%d\n",ans);
  KafuuChino HotoKokoa
}
