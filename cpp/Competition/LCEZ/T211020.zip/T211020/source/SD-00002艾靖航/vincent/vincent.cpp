#include<bits/stdc++.h>
#define LL long long
#define dv double
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define pub push_back
#define pii pair<int,int>
#define mkp make_pair
#define x first
#define y second
#define KafuuChino return
#define HotoKokoa 0;
using namespace std;
il void Read(int &x){
  int f=1;x=0;char c=getchar();
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(x<<3)+(x<<1)+c-'0',c=getchar();
  }
  x*=f;
}
const int N=2000010;
int n,f[65][N];
int main(){
  freopen("vincent.in","r",stdin);
  freopen("vincent.out","w",stdout);
  int st=clock();
  Read(n);int ans=0;
  for(rg int i=1,x;i<=n;i++)Read(x),f[x][i]=i+1;
  for(rg int i=2;i<=60;i++){
    for(rg int j=1;j<=n;j++){
      if(!f[i][j]&&f[i-1][f[i-1][j]]){
        f[i][j]=f[i-1][f[i-1][j]];
      }
      if(f[i][j])ans=i;
    }
  }
  printf("%d\n",ans);
  cerr<<(dv)(clock()-st)/CLOCKS_PER_SEC<<endl;
  KafuuChino HotoKokoa
}
