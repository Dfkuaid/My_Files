#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<math.h>
#include<queue>
#define ll long long
using namespace std;

const ll inf=1e9+7;

inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

const ll maxn=5e5+5;
ll n,a[maxn],p[maxn];
int main(){
	freopen("thunder.in", "r", stdin);
	freopen("thunder.out", "w", stdout);
	n=read();
	for (int i = 1; i <= n; i++) a[i]=read();
	
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=n;j++)
		{
			p[i]=max(p[i],a[j]-a[i]+(long long)ceil(sqrt(abs(i - j))));
		}
	}
	
	for (int i=1;i<=n;i++) printf("%lld\n",p[i]);
	
	return 0;
}
