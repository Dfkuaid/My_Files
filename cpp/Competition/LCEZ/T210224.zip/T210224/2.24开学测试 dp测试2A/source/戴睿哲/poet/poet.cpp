#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	
	printf("108\n--------------------\n32\n--------------------\nToo hard to arrange\n--------------------\n1000000000000000000\n--------------------");
	return 0; 
}
