#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;

const int maxn=1001;
int q[maxn];
int f[maxn],x[maxn],p[maxn],c[maxn],s[maxn],b[maxn];

inline double cal(int x,int y)
{
    return double(f[x]-f[y]+b[x]-b[y])/double(s[x]-s[y]);
} 

int main()
{
    freopen("pasture.in","r",stdin);
    freopen("pasture.out","w",stdout);
    
    int n;
    scanf("%d",&n);
    
	for(int i=1;i<=n;i++)
	scanf("%d",&c[i]);
	
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&p[i]);
        x[i]=i-1;
        s[i]=s[i-1]+p[i];
        b[i]=b[i-1]+p[i]*x[i];
    }
    
    int l=0,r=0;
    for(int i=1;i<=n;i++)
    {
        while(l<r&&cal(q[l+1],q[l])<=x[i])
		l++;
		
        int num=q[l];
        f[i]=f[num]+(s[i-1]-s[num])*x[i]-b[i-1]+b[num]+c[i];
        
        while(l<r&&cal(q[r],q[r-1])>=cal(i,q[r]))
		--r;
		
        q[++r]=i;
    }
    
    printf("%d",f[n]);
    
    return 0;
}
