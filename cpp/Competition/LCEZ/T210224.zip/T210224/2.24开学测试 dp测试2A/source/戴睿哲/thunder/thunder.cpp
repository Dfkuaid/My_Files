#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;

int a[500001];
bool fg=true;

int main()
{
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	
	int n;
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	
	for(int i=1;i<=n;i++)
	{
		for(int l=1;l<=5000;l++)
		{
			fg=true;
			for(int g=1;g<=n;g++)
			{
				double zysad=sqrt(abs(i-g));
				if(a[g]*1.0>a[i]*1.0+l*1.0-zysad)
				{
					fg=false;
					break;
				}
			}
			if(fg)
			{
				printf("%d\n",l);
				break;
			}
		}
	}
	
	return 0;
	
}

/*
6
5
3
2
4
2
4
*/
