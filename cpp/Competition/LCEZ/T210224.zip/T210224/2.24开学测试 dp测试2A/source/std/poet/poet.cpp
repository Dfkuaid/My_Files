#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<queue>
#define ll long double
#define inf 9000000000000000000
#define MAX 1000000000000000000LL
using namespace std;
int T,n,l,p,top;
ll sum[100005],f[100005],from[100005];
char ch[100005][35];
struct data{int l,r,p;}q[100005];
int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
ll pow(ll x)
{
	if(x<0)x=-x;
	ll ans=1;
	for(int i=1;i<=p;i++)
		ans*=x;
	return ans;
}
ll cal(int j,int i)
{
	return f[j]+pow(sum[i]-sum[j]+(i-j-1)-l);
}
int find(data t,int x)
{
    int l=t.l,r=t.r;
    while(l<=r)
    {
        int mid=(l+r)>>1;
        if(cal(t.p,mid)<cal(x,mid))
            l=mid+1;
        else r=mid-1;
    }
    return l;
}
void dp()
{
	int head=1,tail=0;
	q[++tail]=(data){0,n,0};
	for(int i=1;i<=n;i++)
    {
		if(head<=tail&&i>q[head].r)head++;
		f[i]=cal(q[head].p,i);
		from[i]=q[head].p;
		if(head>tail||cal(i,n)<=cal(q[tail].p,n))
		{
			while(head<=tail&&cal(i,q[tail].l)<=cal(q[tail].p,q[tail].l))
				  tail--;
			if(head>tail)
				q[++tail]=(data){i,n,i};
			else 
			{
				int t=find(q[tail],i);
				q[tail].r=t-1;
				q[++tail]=(data){t,n,i};
			}
		}
	}
}
int main()
{
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();l=read();p=read();
		for(int i=1;i<=n;i++)
			scanf("%s",ch[i]);
		for(int i=1;i<=n;i++)
			sum[i]=sum[i-1]+strlen(ch[i]);
		dp();
		if(f[n]>MAX)
			puts("Too hard to arrange");
		else 
			printf("%I64d\n",(long long)f[n]);
		puts("--------------------");
	}
	return 0;
}
 

