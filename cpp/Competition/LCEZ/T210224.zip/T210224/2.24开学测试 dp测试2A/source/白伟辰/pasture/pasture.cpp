#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
//f[i] ����ǰi������ �ڵ�i����վ 
long long f[2001];
long long a[2001],b[2001];
long long n;
inline long long cost(long long s,long long e){
	long long sum=0;
	for(int i=s+1;i<e;i++){
		sum+=(e-i)*b[i];
	}
	return sum;
}
long long final(long long last){
	long long sum=0;
	for(long long i=last+1;i<=n;i++){
		sum+=b[i]*(i-last);
	}
	return sum;
}
int main(){
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	} 
	for(int i=1;i<=n;i++){
		cin>>b[i]; 
	}
	memset(f,0x3f,sizeof(f));
	f[0]=0;
	//cout<<cost(0,4)<<endl;
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			f[i]=min(f[i],f[j]+cost(j,i)+a[i]);
			//cout<<i<<" "<<j<<" "<<f[i]<<" "<<f[j]<<endl;
		}
	}
	/*for(int i=0;i<=n;i++)
		cout<<f[i]<<" ";
	cout<<endl;*/
	cout<<f[n]<<endl; 
	//long long min1=0x7fffffff;
	/*for(int i=1;i<=n;i++){
		if(f[i]+final(i)<min1)
			min1=min(min1,f[i]+final(i)),cout<<i<<" ";
	}
	cout<<endl<<min1<<endl;*/
	return 0;
}
