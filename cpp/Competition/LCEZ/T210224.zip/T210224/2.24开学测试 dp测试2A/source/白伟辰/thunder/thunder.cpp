#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
long long a[2000001];
int main(){
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		double max1=-1;
		for(int j=1;j<=n;j++){
			max1=max(a[j]+sqrt(abs(i-j)),max1);
		}
		max1-=a[i];
		max1*=10;
		long long m1=max1,m2=0;
		if(m1%10!=0)	m2++;
		m2+=m1/10;
		cout<<m2<<endl;
	}
	return 0;
}
