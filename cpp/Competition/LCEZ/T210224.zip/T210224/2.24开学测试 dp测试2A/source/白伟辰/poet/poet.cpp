#include <iostream>
#include <cmath>
#define ll long long
using namespace std;
long long a[100001];
//f[i][j] ǰ 
int main(){
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	int t;
	cin>>t;
	for(int t1=1;t1<=t;t1++){
		bool fail=0;
		ll n,l,p;
		cin>>n>>l>>p;
		for(int i=1;i<=n;i++){
			string temp;
			cin>>temp;
			a[i]=temp.length();
		}
		ll sum=0;
		ll now=0;
		for(ll i=1;i<=n;i++){
			if(now!=0&&pow(abs(a[i]+now-l+1),p)<pow(abs(a[i]-l),p)+pow(abs(now-l),p)){
				now+=a[i]+1;
			//	cout<<i<<":"<<1<<endl;
			} 
			else{
				if(i!=1)
					sum+=pow((abs(now-l)),p);
				now=a[i];
				//cout<<i<<":"<<2<<endl;
			}
			if(sum>1000000000000000000){
				cout<<"Too hard to arrange"<<endl;
				fail=1;
				break;
			}
		//	cout<<now<<" "<<sum<<endl;
		} 
		if(fail==0){
			sum+=pow((abs(now-l)),p);
			if(sum>1000000000000000000){
					cout<<"Too hard to arrange"<<endl;
					fail=1;
			}
			else
				cout<<sum<<endl;
		}
		cout<<"--------------------";
		if(t!=t1) cout<<endl;
	}
	return 0;
}
