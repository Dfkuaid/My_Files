#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
const int maxn = 5e5 + 5;
int n, a[maxn], head, tail;
double sq[maxn], f[maxn];
struct node{
	int l, r, p;
} q[maxn];
double work(int j, int i){
	return (double)a[j] + sq[i - j];
}
int search(int t, int x){
	int ans = q[t].r + 1, l = q[t].l, r = q[t].r, mid;
	while (l <= r){
		mid = (l + r) / 2;
		if (work(q[t].p, mid) <= work(x, mid)) ans = mid, r = mid - 1;
		else l = mid + 1;
	}
	return ans;
}
void insert(int i){
	q[tail].l = max(q[tail].l, i);
	while (head <= tail && work(i, q[tail].l) >= work(q[tail].p, q[tail].l)) tail--;
	if (head > tail){
		q[++tail].l = i;
		q[tail].r = n;
		q[tail].p = i;
	}
	else{
		int pos = search(tail, i);
		if (pos > n) return;
		q[tail].r = pos - 1;
		q[++tail].l = pos;
		q[tail].r = n;
		q[tail].p = i;
	}
}
void solve(){
	head = 1; tail = 0;
	for (int i = 1; i <= n; i++){
		insert(i);
		if (head <= tail && q[head].r < i) head++;
		else q[head].l = i;
		f[i] = max(f[i], work(q[head].p, i));
	}
}
int main(){
	freopen("thunder.in", "r", stdin);
	freopen("thunder.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++){
		scanf("%d", &a[i]);
		sq[i] = sqrt(i);
	}
	solve();
	for (int i = 1; i <= n / 2; i++){
		swap(a[i], a[n - i + 1]);
		swap(f[i], f[n - i + 1]);
	}
	solve();
	for (int i = n; i >= 1; i--) printf("%d\n", (int)ceil(f[i]) - a[i]);
	return 0;
}
