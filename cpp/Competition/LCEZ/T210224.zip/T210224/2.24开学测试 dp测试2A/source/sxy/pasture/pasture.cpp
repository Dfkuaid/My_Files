#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<stack>
#include<cmath>
#include<queue>
#include<map>
using namespace std;
typedef long long ll;

inline ll read()
{
    ll x=0,f=0;
    char ch=getchar();
    while(!isdigit(ch)) f|=(ch=='-'),ch=getchar();
    while(isdigit(ch)) x=(x<<1)+(x<<3)+(ch^=48),ch=getchar();
    return f?-x:x;
}

int n,a[1000002],b[1000002],q[100002];
ll f[1000002],sb[1000003],sib[1000003];

ll val(int j,int i)
{
    return f[j] + (ll)a[i] + i*(sb[i-1]-sb[j]) - (sib[i-1]-sib[j]);
}

inline double Count(int j,int k) //б��
{
    return 1.0*(f[j]+sib[j]-f[k]-sib[k])/(double)(sb[j]-sb[k]);
}
    
int main()
{
    freopen("pasture.in","r",stdin);
    freopen("pasture.out","w",stdout);
    n=read();
    
    for(int i=1;i<=n;++i)
    a[i]=read();
    
    for(int i=1;i<=n;++i)
    {
        b[i]=read();
        sb[i]=sb[i-1]+(ll)b[i];
        sib[i]=sib[i-1]+(ll)i*(ll)b[i];
    }
    
    if(n<=1000)
    {
        for(int i=1;i<=n;++i)
        f[i]=1e6;
        f[0]=0;
        f[1]=0;
        for(int i=1;i<=n;++i) 
        {
            for(int j=1;j<=i;++j)
            {
                if(i==1)
                f[i]=f[j] + (ll)a[i] + i*(sb[i-1]-sb[j]) - (sib[i-1]-sib[j]);
                else
                f[i]=min(f[i],f[j] + (ll)a[i] + i*(sb[i-1]-sb[j]) - (sib[i-1]-sib[j]));
            }
        }
        printf("%lld\n",f[n]);
        return 0;
    }
    
    ll l=1,r=1;
    for(int i=1;i<=n;i++) 
    {
		while(l<r&&Count(q[l+1],q[l])<=i)l++;
        f[i]=f[q[l]]+a[i]+i*(sb[i-1]-sb[q[l]])-(sib[i-1]-sib[q[l]]);
		while(l<r&&Count(q[r],q[r-1])>=Count(i,q[r]))r--;
		q[++r]=i;
    }
    printf("%lld\n",f[n]);
    return 0;
}
