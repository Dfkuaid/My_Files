#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<math.h>
#include<queue>
#define ll long double
using namespace std;

const int maxn=1e5+10;
const ll inf=1e18;
ll L;
int T,n,p,top;
int head=1,tail=1;
ll f[maxn];
int a[maxn];
int sum[maxn];
int sta[maxn];
int pre[maxn];
char ch[maxn][32];
struct node
{
	int l,r,j;
} s[maxn];

inline int aabs(int x)
{
	return x<0 ? -x : x; 
}

inline ll ksm(ll a,int b)
{
	ll ret=1;
	while(b)
	{
		if(b&1) ret=ret*a;
		a=a*a;
		b>>=1;
	}
	return ret;
}

inline ll val(int j,int i)
{
	return f[j]+ksm(aabs((sum[i]-sum[j])-L+(i-j-1)),p);
}

inline void binary_s(int x)
{
	int l=s[tail].l,r=s[tail].r,c=s[tail].j;
	int ret=r+1;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(val(x,mid)<=val(c,mid)) r=mid-1,ret=mid;
		else l=mid+1;
	}
	if(ret!=s[tail].l) s[tail].r=ret-1;
	else tail--;
	if(ret<=n)
	{
		s[++tail].j=x;
		s[tail].l=ret;
		s[tail].r=n;
	}
	return ;
}

int main(void)
{
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	
	cin>>T;
	
	while(T--)
	{
		cin>>n>>L>>p;
		top=0;
		head=1,tail=1;
		memset(pre,0,sizeof(pre));
		memset(sum,0,sizeof(sum));
		memset(ch,0,sizeof(ch));
		memset(s,0,sizeof(s));
		for(int i=1;i<=n;i++)
		{
			scanf("%s",ch[i]);
			int len=strlen(ch[i]);
			sum[i]=sum[i-1]+len;
			f[i]=0;
		}
		f[0]=0;
		s[1].j=0;
		s[1].l=1;
		s[1].r=n;
		for(int i=1;i<=n;i++)
		{
			while(head<tail&&s[head].r<=i-1) head++;
			s[head].l=i;
			f[i]=val(s[head].j,i);
			pre[i]=s[head].j;
			while(head<tail&&(val(s[tail].j,s[tail].l)>=val(i,s[tail].l))) tail--;
			binary_s(i);
		}
		if(f[n]>inf) 
		{
			printf("Too hard to arrange\n");
		}
		else 
		{
			printf("%lld\n",(long long)(f[n]+0.5));
		}
		printf("--------------------");
		if(T>0)
		{
			putchar(10);
		}
	}
	return 0;
}
