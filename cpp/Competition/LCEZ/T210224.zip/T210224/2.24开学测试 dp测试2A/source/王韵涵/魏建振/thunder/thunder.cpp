#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long int ll;
const int maxn=500005;
int n,maxx,hao,c[maxn];
double a[maxn],f[maxn];
int main(){
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lf",&a[i]);
		if(a[i]>maxx){
			maxx=a[i];
			hao=i;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			double x=a[j]-a[i]+sqrt(abs(i-j));
			int an=ceil(x);
			c[i]=max(c[i],an);
		}
	}
	for(int i=1;i<=n;i++){
		printf("%d\n",c[i]);
	}
	return 0; 
} 
