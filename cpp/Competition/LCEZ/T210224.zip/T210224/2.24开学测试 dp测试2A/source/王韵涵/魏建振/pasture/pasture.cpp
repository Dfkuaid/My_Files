#include <cstdio>
#include <algorithm>

using namespace std;

typedef long long int ll;
const int maxn=100005;
int n,a[maxn],b[maxn],f[maxn],s[maxn],sb[maxn];
int get(int x,int y){
	int an=0;
	for(int i=x+1;i<=y;i++){
		an+=(b[i]*(y-x));
	}
	return an;
}
int main(){
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		f[i]=0x3f3f3f3f;
		
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
		sb[i]=sb[i-1]+b[i];
		s[i]=s[i-1]+sb[i];
	}
	f[0]=0;	
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			f[i]=min(f[i],f[j]+s[i-1]-s[j]-(i-j-1)*sb[j]+a[i]);
		}
	}
	printf("%d\n",f[n]);
}

