#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>

using namespace std;

typedef long long int ll;
const int maxn=100005;
int T,n,l,p,k;
char b[maxn];
long double f[maxn],s[maxn],a[maxn] ;
long double ksm(long double a,ll k){
	long double y=1;
	while(k>0){
		if(k%2==1) y=y*a;
		a=a*a;
		k/=2;
	} 
	return y;
}
long double gp(long double x){
	return ksm(x,p);
}
long double abcs(long double x){
	if(x>0)return x;
	return -x;
}
int main(){
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d%d",&n,&l,&p);
		for(int i=1;i<=n;i++){
			scanf("%s",&b);
			a[i]=strlen(b);
			s[i]=s[i-1]+a[i];
			f[i]=1e19;
		}
		f[1]=ksm(abcs(s[1]-l),p);
		for(int i=1;i<=n;i++){
			for(int j=0;j<=i-1;j++){
				f[i]=min(f[i],f[j]+ksm(abs(s[i]-s[j]+i-j-l-1),p));
			}
		}
		if(f[n]>1e18){
			printf("Too hard to arrange\n");
			puts("--------------------");
		}
		else{
			printf("%lld\n",(ll)f[n]);
				puts("--------------------");
		}
	}
	return 0;
}
