#include <bits/stdc++.h>
using namespace std;
int read()
{
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + ch - '0';
        ch = getchar();
    }
    return x * f;
}
void write(const long long& x)
{
    if (!x)
    {
        putchar('0');
        return;
    }
    char f[100];
    long long tmp = x;
    if (tmp < 0)
    {
        tmp = -tmp;
        putchar('-');
    }
    long long s = 0;
    while (tmp > 0)
    {
        f[s++] = tmp % 10 + '0';
        tmp /= 10;
    }
    while (s > 0)
    {
        putchar(f[--s]);
    }
}
int totN;
int l = 1;
long long r;
long long A[1000090], B[1000090];
int DPS[1000090];
long long totCOS, ans;
long long DP[1000090], sum[1000090];
double cal(int j, int k)
{
    return (double)(DP[k] - DP[j]) / (double)(j - k);
}
int main()
{
    freopen("pasture.in","r",stdin);
    freopen("pasture.out","w",stdout);
    totN = read();
    for (int i = 1; i <= totN; i++)
        A[i] = read();
    for (int i = 1; i <= totN; i++)
        B[i] = read();
    for (int i = 1; i <= totN; i++)
        sum[i] = sum[i - 1] + B[i];
    for (int i = 1; i < totN; i++)
        totCOS += B[i] * (totN - i);
    totCOS += A[totN];
    DPS[++r] = totN;
    for (int i = totN - 1; i; i--)
    {
        while (l < r && cal(DPS[l], DPS[l + 1]) > sum[i])
            l++;
        int j = DPS[l];
        DP[i] = DP[j] + sum[i] * (j - i) - A[i];
        ans = max(ans, DP[i]);
        while (l < r && cal(DPS[r], i) > cal(DPS[r - 1], DPS[r]))
            r--;
        DPS[++r] = i;
    }
    write(totCOS - ans);
    return 0;
}
