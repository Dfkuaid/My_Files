#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<queue>
#define ll long long
#define inf 9000000000000000000
#define MAX 1000000000000000000LL
using namespace std;
int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int n;
int a[1000005],b[1000005];
ll tot,ans,f[1000005],sum[1000005];
int main()
{
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=n;i++)b[i]=read();
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+b[i];
	for(int i=1;i<n;i++)
		tot+=b[i]*(n-i);
	tot+=a[n];
	for(int i=n-1;i;i--)
	{
		for(int j=i+1;j<=n;j++)
			f[i]=max(f[i],f[j]+sum[i]*(j-i)-a[i]);
		ans=max(ans,f[i]);
	}
	printf("%I64d",tot-ans);
	return 0;
}

