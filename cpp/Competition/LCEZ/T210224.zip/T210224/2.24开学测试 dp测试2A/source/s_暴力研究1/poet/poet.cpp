#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<queue>
#define ll long long
#define inf 9000000000000000000
#define MAX 1000000000000000000LL
using namespace std;
int T,n,l,p,top;
int q[2005];
ll sum[2005],f[2005],from[2005];
char ch[2005][35];
int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
ll pow(ll x)
{
	if(x<0)x=-x;
	ll ans=1;
	for(int i=1;i<=p;i++)
		if((long double)ans*x>MAX)return MAX+1;
		else ans*=x;
	return ans;
}
void dp()
{
	for(int i=1;i<=n;i++)f[i]=inf;
	f[0]=0;
	for(int i=1;i<=n;i++)
		for(int j=0;j<i;j++)
		{
			ll t=f[j]+pow(sum[i]-sum[j]+(i-j-1)-l);
			if(t<=f[i])f[i]=t,from[i]=j;
		}
}
int main()
{
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();l=read();p=read();
		for(int i=1;i<=n;i++)
			scanf("%s",ch[i]);
		for(int i=1;i<=n;i++)
			sum[i]=sum[i-1]+strlen(ch[i]);
		dp();
		if(f[n]>MAX)
			puts("Too hard to arrange");
		else 
			printf("%I64d\n",f[n]);
		puts("--------------------");
	}
	return 0;
}

