 #include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int a[1000001],T[1000001],n,dp[1000001],su[1000001],ts[1000001];
int main()
{
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	cin>>n;
	memset(dp,0x3f,sizeof(dp));
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
		cin>>T[i];
	for(int i=1;i<=n;i++)
    su[i]=su[i-1]+T[i];
  for(int i=1;i<=n;i++)
    ts[i]=ts[i-1]+su[i];
	dp[0]=0;
  for (int i=1;i<=n;i++)
	{ 
    for (int j=0;j<i;j++)
		{
      dp[i]=min(dp[j]+a[i]+ts[i-1]-ts[j]-(i-j-1)*su[j],dp[i]);
    }
  }
	cout<<dp[n];
	return 0;
}
