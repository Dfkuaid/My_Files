#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
long long n,a[500001];
int main()
{
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
	{
		int p=-0x7fffffffffff;
		for(int j=1;j<=n;j++)
		{
			p=max((long long)(p,a[j]-a[i]+ceil(sqrt(abs(i-j)))),(long long)p);
		}
		cout<<p<<endl;
	}
	return 0;
}
