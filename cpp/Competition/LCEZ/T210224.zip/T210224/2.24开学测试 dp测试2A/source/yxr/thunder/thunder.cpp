#include<bits/stdc++.h>
#define ll long long
#define maxn 500000+7
using namespace std;

inline ll read()//��� 
{
    char c=getchar();
    ll x=0,f=1;
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}//����Ҫ�и�ɾ������ 
    while(isdigit(c))x=(x<<3)+(x<<1)+(c^48),c=getchar();
    return x*f;
}

ll n;
ll a[maxn];
long double zheng_f[maxn],dao_f[maxn];
/*
void solve1(int L,int R,int l,int r)
{
	if (L>R) return;
	int mid=(L+R)>>1,g(0);
	long double tmp(0);
	zheng_f[mid]=a[mid];
	for (int i=l;i<=min(r,mid);i++)
	{
		tmp=a[i]+sqrt(double(mid-i));
		if (tmp>zheng_f[mid]) zheng_f[mid]=tmp,g=i;
	}
	if (g==0) g=mid; zheng_f[mid]-=a[mid];
	solve1(L,mid-1,l,g); 
	solve1(mid+1,R,g,r);
}*/
void work_zheng(ll L,ll R,ll l,ll r)
{
	if(L>R) return ;
	ll mid=(L+R)>>1,k=0;
	zheng_f[mid]=a[mid];
	ll q=min(mid,r);
	for(int i=l;i<=q;i++)
	{
		long double tmp=a[i]+sqrt(double(abs(mid-i)));
		if(tmp>zheng_f[mid]) zheng_f[mid]=tmp,k=i; 
	}
	
	if(k==0) k=mid;zheng_f[mid]-=a[mid]; 
	work_zheng(L,mid-1,l,k);
	work_zheng(mid+1,R,k,r);
}

void work_dao(ll L,ll R,ll l,ll r)
{
	if(L>R) return;
	ll mid=(L+R)>>1,k=0;
	dao_f[mid]=a[mid];
	ll q=max(mid,l);
	for(int i=r;i>=q;i--)
	{
		long double tmp=a[i]+sqrt(double(abs(mid-i)));
		if(tmp>dao_f[mid]) dao_f[mid]=tmp,k=i;
	}
	
	if(k==0) k=mid;dao_f[mid]-=a[mid];
	work_dao(L,mid-1,l,k);
	work_dao(mid+1,R,k,r);
} 
/*
void solve2(int L,int R,int l,int r)
{
	if (L>R) return ;
	int mid=(L+R)>>1,g(0);
	long double tmp(0);
	dao_f[mid]=a[mid];
	for (int i=r;i>=max(mid,l);i--)
	{
		tmp=a[i]+sqrt(double(i-mid));
		if (tmp>dao_f[mid]) dao_f[mid]=tmp,g=i;
	}
	if (g==0) g=mid; dao_f[mid]-=a[mid];
	solve2(L,mid-1,l,g);
	solve2(mid+1,R,g,r);
}
*/

int main()
{
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	/*//Ԥ����������ѭ��ʱ��һ������p
	ll zheng_p=0;
	double tmp=0;
	ll jj=0;
	for(int j=1;j<=n;j++)
	{
		tmp=sqrt(abs(1-j));
		if((int)tmp!=tmp)//����������� 
		tmp=(int)tmp+1;
		
		if(zheng_p<a[j]-a[1]+tmp) 
		{
			zheng_p=max(zheng_p,a[j]-a[1]+(int)tmp);
			jj=j;
		}
		
	}
	zheng_f[1]=zheng_p;
	//������
	tmp=0; 
	double tmp2=0;
	for(int i=2;i<=n;i++)
	{
		tmp=sqrt(abs(jj-(i-1)));
		tmp2=sqrt(abs(jj-i));
		if((int)tmp!=tmp) tmp=(int)tmp+1;
		if((int)tmp2!=tmp2) tmp2=(int)tmp2+1;
		zheng_f[i]=max(zheng_f[i],zheng_f[i-1]-(int)tmp+a[i-1]-a[i]+(int)tmp2);
	} 
	
	
	
	//Ԥ����������ѭ��ʱ��һ������p 
	ll dao_p=0;
	tmp=0;
	jj=0;
	for(int j=n;j>=1;j--)
	{
		tmp=sqrt(abs(n-j));
		if((int)tmp!=tmp)//����������� 
		tmp=(int)tmp+1; 
		if(dao_p<a[j]-a[n]+tmp)
		{
			dao_p=max(dao_p,a[j]-a[n]+(int)tmp);
			jj=j;
		}	
	}
	
	dao_f[n]=dao_p;
	
	//������
	for(int i=n-1;i>=1;i--)
	{
		tmp=sqrt(abs(jj-(i+1)));
		tmp2=sqrt(abs(jj-i));
		if((int)tmp!=tmp) tmp=(int)tmp+1;
		if((int)tmp2!=tmp2) tmp2=(int)tmp2+1;
		dao_f[i]=max(dao_f[i],a[jj]-a[i]+(int)tmp2);
	} 
	
	for(int i=1;i<=n;i++)
	{
		cout<<max(zheng_f[i],dao_f[i])<<"\n";
	}
	
	/*cout<<'\n';
	for(int i=1;i<=n;i++) cout<<zheng_f[i]<<" ";
	cout<<'\n';
	for(int i=1;i<=n;i++) cout<<dao_f[i]<<" ";
	*/
	
	work_zheng(1,n,1,n);
	work_dao(1,n,1,n);
//solve1(1,n,1,n);
//solve2(1,n,1,n);
//cout<<zheng_f[1]<<" "<<dao_f[1]<<'\n';
	for(int i=1;i<=n;i++) cout<<(ll)ceil(max(zheng_f[i],dao_f[i]))<<'\n';
	return 0;
	
}
