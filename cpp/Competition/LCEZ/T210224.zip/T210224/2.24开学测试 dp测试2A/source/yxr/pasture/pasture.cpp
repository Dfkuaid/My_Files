#include<bits/stdc++.h>
#define ll long long
#define maxn 1000010
using namespace std;

ll f[maxn],sum[maxn],s[maxn];

inline ll read()//��� 
{
    char c=getchar();
    ll x=0,f=1;
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}//����Ҫ�и�ɾ������ 
    while(isdigit(c))x=(x<<3)+(x<<1)+(c^48),c=getchar();
    return x*f;
}
ll q[maxn];

ll a[maxn],b[maxn];

ll getup(ll j,ll k)
{
	return f[j]+s[j]-(f[k]+s[k]);
}

ll getdone(ll j,ll k)
{
	return sum[j]-sum[k];
}

ll getdp(ll i,ll j)
{
//	cout<<i<<" sgsr "<<j<<'\n';
	return f[i]=f[j]+a[i]+(ll)i*(sum[i-1]-sum[j])-(s[i-1]-s[j]);
//	f[i]=f[q[head]]+a[i]+i*(sum[i-1]-sum[q[head]])-(s[i-1]-s[q[head]]);
}
ll n;
int main()
{
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++) 
	{
		b[i]=read();
		sum[i]=sum[i-1]+b[i];
		s[i]=s[i-1]+1ll*i*b[i];
	}
	ll head=1,tail=1;
	q[1]=0;
	for(int i=1;i<=n;i++)//����ÿһ��iö�ٶϵ�
	{
		while(head<tail&&getup(q[head+1],q[head])
		<=(ll)i*getdone(q[head+1],q[head]))
		head++/*,cout<<1<<" "*/;
//		cout<<'\n';
		f[i]=getdp(i,q[head]);
//		ll j=q[head];
//		f[i]=f[j]+a[i]+i*(sum[i-1]-sum[j])-(s[i-1]-s[j]);
		while(head<tail&&(ll)getup(i,q[tail])*getdone(q[tail],q[tail-1])
		<=(ll)getup(q[tail],q[tail-1])*getdone(i,q[tail]))
		//���i��tail��б�ʱ�tail-1��tail��б��С��˵��tail���Ϸ���ֱ��ɾ��
		tail--/*,cout<<2<<" "*/;
//		cout<<'\n';
		
		q[++tail]=i; 
//		cout<<head<<" "<<tail<<'\n';
	} 
	/*int l=1,r=1;
    for(int i=1;i<=n;i++){
		while(l<r&&getup(q[l+1],q[l])<=i*getdone(q[l+1],q[l]))l++;
		f[i]=f[q[l]]+a[i]+i*(sum[i-1]-sum[q[l]])-(s[i-1]-s[q[l]]);
		while(l<r&&getup(q[r],q[r-1])*getdone(i,q[r])>=getup(i,q[r])*getdone(q[r],q[r-1]))r--;
		q[++r]=i;
		cout<<l<<" "<<r<<'\n';
    }*/
	
	cout<<f[n]<<'\n';
	
}
