/*n^2*/
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l));
#define mp(a,b) make_pair(a,b)
using namespace std;

const int N = 10010;
const int INF = 0x3fffffff;

int n,a[N],b[N];
ll sum1[N],sum2[N];
ll f[N];

inline ll Min(ll a,ll b){
    return (a < b) ? a : b;
}

//inline void print_f(){
//    for (int i = 1;i <= n;i ++){
//        for (int j = 1;j <= i;j ++)
//          cout << f[i][j] << " \t";
//        cout << endl;
//    }
//} 

int main(){
    freopen("pasture.in","r",stdin);
    freopen("pasture.out","w",stdout);
    scanf("%d",&n);
    for (int i = 1;i <= n;i ++)
      scanf("%d",&a[i]);
    for (int i = 1;i <= n;i ++){
        scanf("%d",&b[i]);
        sum1[i] = sum1[i - 1] + b[i];
        sum2[i] = sum2[i - 1] + sum1[i];
    }
    mset(f,0x3f);
    f[0] = 0;
    for (int i = 1;i <= n;i ++)
//      for (int j = 1;j <= i;j ++)
        for (int k = 0;k < i;k ++){
            ll p = sum2[i - 1] - sum2[k] - sum1[k] * (i - k - 1) + a[i];
//            int ssum = 0;
//            for (int o = k + 1;o < i;o ++)
//              ssum += (i - o) * b[o];
//            ssum += a[i];
//            printf("i=%d\tj=%d\tk=%d\tf[i][j]=%d\tf[k][j - 1]=%d\tnew=%d\tssum=%d\n",i,j,k,f[i][j],f[k][j - 1],p,ssum);
//            print_f();
            f[i] = Min(f[i],f[k] + p);
        }
//    print_f();
    ll ans = INF;
    
    cout << f[n];
    return 0;
}

