#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l));
#define mp(a,b) make_pair(a,b)
using namespace std;

const int N = 100010;
const int INF = 0x3fffffff;
const ll Mod = 1e18;

int t,n,l,p;
ll f[N],a[N],sum[N];

inline ll Min(ll a,ll b){
    return a < b ? a : b;
}

inline ll _abs(ll x){
    return x >= 0 ? x : -x;
}

inline ll M(ll a,int b){
    ll ans = 1;
    for (int i = 1;i <= b;i ++){
        if (ans * a < ans || ans * a > Mod)
          return -1;
        ans *= a;
    }
    return ans;
}

int main(){
    freopen("poet.in","r",stdin);
    freopen("poet.out","w",stdout);
    scanf("%d",&t);
    while (t --){
        mset(f,0x3f);
        scanf("%d%d%d",&n,&l,&p);
        for (int i = 1;i <= n;i ++){
            string s;
            cin >> s;
            a[i] = s.length();
            sum[i] = sum[i - 1] + a[i];
//            ll k = M(_abs(a[i] - l),p);
//            if (k >= 0 && k <= Mod)
//              f[i] = k;
        }
        f[0] = 0;
        for (int i = 1;i <= n;i ++){
            for (int j = 1;j <= i;j ++){
//                cout << "f[i]:" << f[i] << endl;
                ll len = sum[i] - sum[j - 1] + i - j;
                if (len - l == 0){
                    f[i] = f[i - 1];
                    continue;
                }
                ll k = M(_abs(len - l),p);
//                printf("i=%d j=%d k=%lld len=%lld\n",i,j,k,len);
                if (k == -1) continue;
                k += f[j - 1];
                if (k > Mod) continue;
//                cout << "ch\n";
                f[i] = Min(f[i],k);
            }
        }
        if (f[n] <= Mod)
          printf("%lld\n--------------------\n",f[n]);
        else
          printf("Too hard to arrange\n--------------------\n");
        
    }
    return 0;
}

