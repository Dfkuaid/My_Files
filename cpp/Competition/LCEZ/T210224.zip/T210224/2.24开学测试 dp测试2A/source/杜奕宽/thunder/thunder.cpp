#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#include <cmath>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l));
#define mp(a,b) make_pair(a,b)
using namespace std;

const int N = 5100010;
const int INF = 0x3fffffff;

int n;
ll a[N],f[N];

inline int _abs(int x){
    return (x >= 0) ? x :-x;
}

int main(){
    freopen("thunder.in","r",stdin);
    freopen("thunder.out","w",stdout);
    scanf("%d",&n);
    for (int i = 1;i <= n;i ++)
      scanf("%lld",&a[i]);
    
    for (int i = 1;i <= n;i ++){
        ll minn = -INF;
        for (int j = 1;j <= n;j ++){
            if (j == i) continue;
            ll k = ceil(sqrt(_abs(i - j)));
//            cout << k << " " << a[j] - a[i] + k << endl;
            if (a[j] - a[i] + k >= 0)
              minn = max(minn,a[j] - a[i] + k);  
        }
        cout << minn << endl;
    }
    return 0;
}
