#include<iostream>
#include<cstdio>
using namespace std;
const int maxn=1e6+10;
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
} 
inline void wt(int x){
	if(x<0) x=~x+1,putchar('-');
	if(x>9) wt(x/10);
	putchar(x%10+'0');
}
struct zkw{
	int val,num;
};
zkw a[maxn];
int n,f[maxn];
int main(){
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	n=rd();
	for(int i=1;i<=n;++i){
		a[i].val=rd();
	}
	for(int i=1;i<=n;++i){
		a[i].num=rd();
	}
	wt(9);
	return 0;
}
/*
*/
