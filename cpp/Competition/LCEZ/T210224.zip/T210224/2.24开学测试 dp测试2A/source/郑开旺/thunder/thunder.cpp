#include<iostream>
#include<cstdio>
#include<cmath>
#define pn putchar('\n')
using namespace std;
const int maxn=5e5+10;
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
} 
inline void wt(int x){
	if(x<0) x=~x+1,putchar('-');
	if(x>9) wt(x/10);
	putchar(x%10+'0');
}
int n,a[maxn],p,q;
double s[maxn];
int main(){
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	n=rd();
	for(int i=1;i<=n;++i){
		a[i]=rd();
		s[i]=sqrt(i);
	}
	for(int i=1;i<=n;++i){
		p=0;
		for(int j=1;j<=n;++j){
			q=ceil(a[j]-a[i]+s[abs(i-j)]);
			p=max(p,q);
		}
		wt(p);pn;
	}
	return 0;
}
