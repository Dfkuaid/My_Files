#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#define ll long double
#define pn putchar('\n')
using namespace std;
const int maxn=1e5+10;
inline int rd(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0' || ch>'9'){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(ch>='0' && ch<='9'){
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
ll ksm(ll a,long long k){
	ll y=1;
	while(k>0){
		if(k%2==1) y=y*a;
		a=a*a;
		k/=2;
	} 
	return y;
}
int t,n,l,p,k;
char a[35];
ll w[maxn],s[maxn];
ll f[maxn];
int main(){
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	t=rd();
	while(t--){
		n=rd();l=rd();p=rd();
		for(int i=1;i<=n;++i){
			scanf("%s",a);
			w[i]=strlen(a);
			s[i]=s[i-1]+w[i];
			f[i]=1e19;
		}
		f[1]=ksm(abs(s[1]-l),p);
		for(int i=1;i<=n;++i){
			for(int j=0;j<i;++j){
				f[i]=min(f[i],f[j]+ksm(abs(s[i]-s[j]+i-j-l-1),p));
			}
		}
		if(f[n]>1e18) printf("Too hard to arrange");
		else printf("%lld",(long long)f[n]);
		pn;
		puts("--------------------");
	}
	return 0;
}
