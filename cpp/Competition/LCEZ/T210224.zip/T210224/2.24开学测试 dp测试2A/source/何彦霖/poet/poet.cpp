#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N 100010
#define M 31
using namespace std;

inline ll Min(ll a,ll b){
	return a>b?b:a;
}

const ll mod=1e18;

ll n,l,p,f[N],a[N],sum[N],t;

inline ll ksm(ll a,int b){
	ll res=1;
	while(b){
		if(b&1) res*=a;
		a*=a;
		b>>=1;
		if(res>mod) return -1;
	}
	return res;
}

int main(){
	freopen("poet.in","r",stdin);
	freopen("poet.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		memset(f,0,sizeof(f));
		memset(a,0,sizeof(a));
		memset(sum,0,sizeof(sum));
		scanf("%d%d%d",&n,&l,&p);
		if(n<=10000){
			bool op=0;
			for(int i=1;i<=n;i++){
				char s[M];
				scanf("%s",s+1);
				a[i]=strlen(s+1);
				sum[i]=sum[i-1]+a[i];
			}
			for(int i=1;i<=n;i++){
				ll mi1=ksm(abs(l-a[i]),p);
//				if(mi==-1) continue;
				if(mi1!=-1) f[i]=mi1+f[i-1];
				else f[i]=mod+1;
				for(int j=1;j<=i-1;j++){
					ll mi=ksm(abs(sum[i]-sum[j-1]+i-j-l),p);
					if(mi==-1) continue;
					mi+=f[j-1];
					if(mi>mod) continue;
					if(f[i]) f[i]=Min(f[i],mi);
					else f[i]=mi;
				}
				if(!f[i]){
					op=1;
					printf("Too hard to arrange\n--------------------\n");
					break;
				}
			}
			if(!op&&f[n]!=mod+1) printf("%lld\n--------------------\n",f[n]);
			else if(!op&&f[n]==mod+1) printf("Too hard to arrange\n--------------------\n");
//			else if(!op) printf("Too hard to arrange\n--------------------\n");
		}
	}
	return 0;
}
