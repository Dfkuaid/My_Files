#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N 1000010
#define M number
using namespace std;

ll n,a[N],b[N];
ll sumb[N],ssumb[N],f[N];

inline ll read(){
	ll size=0,flag=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') flag=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		size=size*10+c-48;
		c=getchar();
	}
	return size*flag;
}

const ll INF=0x3f3f3f3f;

inline ll Min(ll a,ll b){
	return a>b?b:a;
}

ll q[N];
ll l=1,r=1;

inline ll y(ll k){
//	printf("k:%d y:%d\n",k,f[k]-ssumb[k]+sumb[k]*k);
	return f[k]-ssumb[k]+sumb[k]*k;
}

inline ll zhuanyi(ll i,ll j){
	f[i]=f[j]+ssumb[i-1]-ssumb[j]-sumb[j]*(i-j-1)+a[i];
}

int main(){
	freopen("pasture.in","r",stdin);
	freopen("pasture.out","w",stdout);
	memset(f,INF,sizeof(f));
//	scanf("%lld",&n);
	n=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=n;i++){
//		scanf("%lld",&b[i]);
		b[i]=read();
		sumb[i]=sumb[i-1]+b[i];
		ssumb[i]=ssumb[i-1]+sumb[i];
//		printf("i:%d sumb:%d ssumb:%d\n",i,sumb[i],ssumb[i]);
	}
	f[0]=0;q[1]=0;
	for(int i=1;i<=n;i++){
//		for(int j=0;j<=i-1;j++){
//			f[i]=Min(f[i],f[j]+ssumb[i-1]-ssumb[j]-sumb[j]*(i-j-1)+a[i]);
//			printf("i:%d f:%d\n",i,f[i]);
		while((y(q[l+1])-y(q[l]))<=(i-1)*(sumb[q[l+1]]-sumb[q[l]])&&l<r)
			l++;
		zhuanyi(i,q[l]);
//			printf("i:%d f:%d q[l]:%d l:%d\n",i,f[i],q[l],l);
		while((y(i)-y(q[r]))*(sumb[q[r]]-sumb[q[r-1]])<=(y(q[r])-y(q[r-1]))*(sumb[i]-sumb[q[r]])&&l<r)
			r--;
		q[++r]=i;
//		}
//		printf("i:%d f:%d\n",i,f[i]);
////		printf("______________________\n");
	}
	printf("%lld\n",f[n]);
	return 0;
}
