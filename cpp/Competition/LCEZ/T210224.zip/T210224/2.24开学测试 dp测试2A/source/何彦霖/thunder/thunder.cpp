#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N 500010
#define M number
using namespace std;

const int INF=0x3f3f3f3f;

ll n,a[N],f[N],g[N];

int main(){
	freopen("thunder.in","r",stdin);
	freopen("thunder.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n;i++){
		ll now=0;
		for(int j=1;j<=n;j++){
			if(i==j) continue;
			ll shang=ceil(sqrt(abs(i-j)));
			now=max(now,max(a[j]-a[i]+shang,(ll)0));
		}
		printf("%lld\n",now);
	}
	return 0;
}
