#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#define ABS(x) ((x) > 0 ? (x) : -(x))
#define MAX(x, y) ((x) > (y) ? (x) : (y))
using namespace std;
const int MAXN = 500005;
inline int read() {
    int s = 0, w = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') s = s * 10 + ch - '0', ch = getchar();
    return s * w;
}
int n, a[MAXN];
// max => { a[j] - a[i] + sqrt(|j - i|) }
int squart[MAXN];  // 向上取整
int main() {
    freopen("thunder.in", "r", stdin);
    freopen("thunder.out", "w", stdout);
    n = read();
    squart[0] = 0;
    for (int i = 1; i <= n; i++) {
        a[i] = read();
        squart[i] = ceil(sqrt(i));
    }
    for (int i = 1; i <= n; i++) {
        int ans = -2147483647;
        for (int j = 1; j <= n; j++) {
            ans = MAX(ans, a[j] - a[i] + squart[ABS(j - i)]);
        }
        printf("%d\n", ans);
    }
    // system("pause");
}