#include <cstdio>
#include <cstring>
#include <deque>
#include <iostream>
using namespace std;
const int MAXN = 1000005;
typedef long long ll;
inline int read() {
    int s = 0, w = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9') {
        if (ch == '-') w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') s = s * 10 + ch - '0', ch = getchar();
    return s * w;
}

int n;
ll a[MAXN], b[MAXN];
ll f[MAXN];  // 滚动数组
// f[i][j] 表示 在前 i 个牧场建立 j 个控制站 的最小费用。
// f[i][j] = max(1 <= k < i) { f[k][j - 1] + value[k + 1][i] }
ll tmp1[MAXN], tmp2[MAXN];
inline ll value(ll x, ll y) {
    return y * (tmp1[y] - tmp1[x - 1]) - (tmp2[y] - tmp2[x - 1]);
}

ll d[MAXN], l = 1, r = 1;

double calc(ll p, ll q) {
    return 1.0 * (f[p] + tmp2[p] - f[q] - tmp2[q]) / (tmp1[p] - tmp1[q]);
}

int main() {
    freopen("pasture.in", "r", stdin);
    freopen("pasture.out", "w", stdout);
    n = read();
    for (int i = 1; i <= n; i++) a[i] = read();
    for (int i = 1; i <= n; i++) b[i] = read();
    for (int i = 1; i <= n; i++) {
        tmp1[i] = tmp1[i - 1] + b[i];
        tmp2[i] = tmp2[i - 1] + b[i] * i;
        // printf("tmp1[%d]:%d,tmp2[%d]:%d\n", i, tmp1[i], i, tmp2[i]);
    }
    // memset(f, 127, sizeof(f));
    // for (int i = 1; i <= n; i++) {
    //     f[i] = value(1, i) + a[i];
    // }
    // for (int i = 2; i <= n; i++) {         // 位置
    //     for (int j = 2; j <= i; j++) {     // 控制站数量
    //         for (int k = 1; k < i; k++) {  // 前面的
    //             // printf("value(%d,%d):%d\n", k + 1, i, value(k + 1, i));
    //             // f[i][j] = min(f[i][j], f[k][j - 1] + value(k + 1, i) +
    //             a[i]); f[i] = min(f[i], f[k] + value(k + 1, i) + a[i]);
    //         }
    //     }
    // }
    for (int i = 1; i <= n; i++) {
        while (l < r && calc(d[l + 1], d[l]) <= i) l++;
        f[i] = f[d[l]] + value(d[l] + 1, i) + a[i];
        while (l < r && calc(d[r], d[r - 1]) >= calc(i, d[r])) r--;
        d[++r] = i;
    }
    printf("%lld\n", f[n]);
    // system("pause");
}
