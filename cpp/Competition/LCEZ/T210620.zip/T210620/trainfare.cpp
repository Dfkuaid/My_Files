#include <iostream>
#include <queue>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define pii pair<int,int>
#define mp(a,b) make_pair(a,b)
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 1000010;
const int INF = 0x3fffffff;

struct Edge{
    int u,v,w;
    int nxt;
};
Edge e[N],ne[N];

int n,m,q,cnt = 2,head[N],ncnt = 1,nhead[N];
int vis[N],dist[N],prep[N],pree[N],id[N],ide[N];
int qt[N],frt = 0,tal = -1,icnt[N],pcnt[N],ans,tag[N];

inline void ADD(const int &u,const int &v,const int &w){
    e[cnt].u = u,e[cnt].v = v,e[cnt].w = w;
    e[cnt].nxt = head[u];head[u] = cnt ++;
}

inline void add(const int &u,const int &v){
//    printf("ADD_EDGE: %d: %d -> %d\n",cnt,u,v);
    ne[ncnt].u = u,ne[ncnt].v = v;icnt[v] ++;
    ne[ncnt].nxt = nhead[u];nhead[u] = ncnt ++;
}

void bfs(){
    mset(dist,0x3f);
    dist[1] = 0;vis[1] = true;
    qt[++ tal] = 1;
    while (frt <= tal){
        
        int now = qt[frt ++];
        for (int i = head[now];i;i = e[i].nxt){
            if (dist[e[i].v] < dist[now] + 1) continue;
            dist[e[i].v] = dist[now] + 1;
            add(now,e[i].v);ide[i / 2] = e[i].v;
            if (!vis[e[i].v]) {
                qt[++ tal] = e[i].v;
                vis[e[i].v] = true;
            }
        }
    }
}

void mark(int x){
//    cout << x << endl;
    if (!x) return;
//    printf("IN: %d\n",x);
    icnt[x] --;tal = -1,frt = 0;
    if (icnt[x]) return;
    tag[x] = true;
    qt[++ tal] = x;ans ++;
    while (frt <= tal){
        int now = qt[frt ++];
        for (int i = nhead[x];i;i = ne[i].nxt){
            if (tag[ne[i].v] || dist[ne[i].v] != dist[x] + 1) continue;
            icnt[ne[i].v] --;
            if (!icnt[x]){
                ans ++;tag[x] = true;
                qt[++ tal] = ne[i].v;
            } 
        }
    }
//    if (!icnt[x]){
//        tag[x] = true;ans ++;
//        for (int i = nhead[x];i;i = ne[i].nxt)
//          if (!tag[ne[i].v] && dist[ne[i].v] == dist[x] + 1)
//            mark(ne[i].v);
//    }
//    printf("RE: %d\n",x);
}

int main(){
   freopen("trainfare.in","r",stdin);
   freopen("trainfare.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);
    for (int i = 1;i <= m;i ++){
        int u,v;scanf("%d%d",&u,&v);
        ADD(u,v,1);ADD(v,u,1);
    }
    bfs();
//    cout << 1 << endl;
//    for (int i = 1;i <= m;i ++)
//      cout << i << " " << id[i] << " " << ide[id[i]] << endl;
//    for (int i = 1;i <= n;i ++)
//      cout << i << " " << icnt[i] << endl;
    while (q --){
//        c
        int k;scanf("%d",&k);
        int u = e[k << 1].u,v = e[k << 1].v;
        if (dist[u] == dist[v]) {
            printf("%d\n",ans);
            continue;
        }
        if (dist[u] < dist[v]) swap(u,v);
//        cout << u << endl;
        mark(u);
        printf("%d\n",ans);
    }
    return 0;
}
