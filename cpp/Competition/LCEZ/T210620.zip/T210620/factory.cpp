#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 100010;
const int INF = 0x3fffffff;

ll n,s,a[N],c[N],f[N],mn = INF;

template <typename T>
inline int Min(T a,T b){
    return a < b ? a : b;
}

int main(){
    freopen("factory.in","r",stdin);
    freopen("factory.out","w",stdout);
    scanf("%lld%lld",&n,&s);
    for (int i = 1;i <= n;i ++){
        scanf("%lld%lld",&c[i],&a[i]);
        mn = Min(mn,c[i] - i * s);
        f[i] = f[i - 1] + a[i] * (mn + i * s);
    }
    printf("%lld",f[n]);
    return 0;
}
