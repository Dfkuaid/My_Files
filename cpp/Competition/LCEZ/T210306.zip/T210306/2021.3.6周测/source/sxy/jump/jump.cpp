#include <cstdio>
int T, n, m, xx1, yy1, xx2, yy2, k1, k2, julian3;
bool qwq(){
	julian3 = 0;
	if (xx1 > xx2) julian3 += xx1 - xx2;
	else julian3 += xx2 - xx1;
	if (yy1 > yy2) julian3 += yy1 - yy2;
	else julian3 += yy2 - yy1;
	return !(julian3 % 2);
}
int main(){
    freopen("jump.in", "r", stdin);
    freopen("jump.out", "w", stdout); 
	scanf("%d", &T); 
	while (T--){
		scanf("%d%d%d%d%d%d%d%d", &n, &m, &xx1, &xx2, &yy1, &yy2, &k1, &k2);
		if (n == 1 || m == 1|| k1 < k2 || (k1 == k2 && qwq()))	printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}