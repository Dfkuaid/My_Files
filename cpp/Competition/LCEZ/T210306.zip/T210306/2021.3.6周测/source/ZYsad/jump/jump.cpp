#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	
	long long T;
	scanf("%lld",&T);
	
	for(long long zysad=1;zysad<=T;zysad++)
	{
		long long n,m,x1,y1,x2,y2,t1,t2;
		scanf("%lld%lld%lld%lld%lld%lld%lld%lld",&n,&m,&x1,&y1,&x2,&y2,&t1,&t2);
		
		if(n==1||m==1)
		{
			printf("YES\n");
			continue;
		}
		
		long long t;
		t=abs(x2-x1)+abs(y2-y1);
		
		if(t%2)
		{
			if(t2>t1)
			printf("YES\n");
			else
			printf("NO\n");
		}
		else
		{
			if(t1<=t2)
			printf("YES\n");
			else
			printf("NO\n");
		}
		
	}
	
	return 0;
}

/*
5
2 8 1 1 2 5
9 9
3 5 3 3 2 3
2 2
6 3 4 1 1 1
3 4
3 3 1 3 3 3
8 7 
2 9 2 1 9 2
6 5


*/
