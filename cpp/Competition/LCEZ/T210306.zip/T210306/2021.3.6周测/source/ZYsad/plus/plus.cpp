#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;

long long a[100001];//n
long long b[100001];//q
const long long mod=998244353;

int main()
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
		
	long long n,q,m;
	scanf("%lld%lld%lld",&n,&q,&m);
	for(long long i=1;i<=q;i++)
	{
		scanf("%lld",&b[i]);
		b[i]%=mod;
	}
		
	for(long long i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		a[i]%=mod;
	}
		
	long long pl,j,c;
	long long giao;
	for(long long zysad=1;zysad<=m;zysad++)
	{
		scanf("%lld%lld%lld",&pl,&j,&c);
		
		c%=mod;
		long long qwq=1;giao=b[j];
		for(long long i=pl;i<=n;i++)
		{
			a[i]=(a[i]+c*qwq%mod)%mod;
			giao=(giao+1)%mod;
			qwq=(giao*qwq/(giao-b[j]))%mod;
		}	
	}
	
	for(long long i=1;i<=n;i++)
		printf("%lld ",a[i]);
	
	return 0;
}

/*

10 1 3
4
0 0 0 0 0 0 0 0 0 0
1 1 1
5 1 1
7 1 2

10 3 4
998244353 1000000007 19260817
9 8 7 6 5 4 3 2 1 10
1 1 987654321
5 2 123456789
3 3 1919810
2 3 114514

*/
