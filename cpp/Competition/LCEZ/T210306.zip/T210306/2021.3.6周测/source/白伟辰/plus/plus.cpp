#include <iostream>
#include <cstdio>
#define ll long long
using namespace std;
const ll mod=998244353;
ll jiecheng[4500001];
ll divjiecheng[4500001];

ll getc(ll n,ll m){
	if(n<=0||m<=0)	return 1;
	if(n>=998244353||m>=998244353)
		return getc(n%mod,m%mod)%mod*getc(n/mod,m/mod)%mod;
//	cout<<1<<" "<<n<<" "<<m<<endl;
//	cout<<jiecheng[m]%mod*divjiecheng[n]%mod*divjiecheng[m-n]%mod<<endl;
	return jiecheng[m]%mod*divjiecheng[n]%mod*divjiecheng[m-n]%mod;
}
ll last;
ll ksm(ll a,ll b){
	ll sum=1;
	while(b){
		if(b&1)
			sum*=a,sum%=998244353;
		b=(b>>1);
		a*=a;
		a%=998244353;
	}
	return sum%998244353;
}
ll div(int x){
	return ksm(x,998244351)%998244353;
}
ll n,q,m;
ll k[11];
ll a[100001];
int main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	jiecheng[0]=1;
	for(int i=1;i<=4500000;i++){
		jiecheng[i]=jiecheng[i-1]*i,jiecheng[i]%=mod;
	}
	divjiecheng[0]=1;
	divjiecheng[1]=1;
	for(int i=2;i<=4500000;i++){
		divjiecheng[i]=div(i)*divjiecheng[i-1]%mod;
	}
//	cout<<divjiecheng[1755653];
//	cout<<getc(1755654,1755654)<<endl;
//	return 0;
	cin>>n>>q>>m;
	for(int i=1;i<=q;i++){
		cin>>k[i];
	}
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=m;i++){
		int pl,j1,c;
		cin>>pl>>j1>>c;
		for(int j=pl;j<=n;j++){
		//	cout<<k[j1]<<" "<<k[j1]+j-pl<<endl;
			a[j]+=c%mod*getc(k[j1],k[j1]+j-pl),a[j]%=mod;
		}
	}
	for(int i=1;i<=n;i++){
		cout<<a[i]%mod<<" ";
	}
	return 0;
}
