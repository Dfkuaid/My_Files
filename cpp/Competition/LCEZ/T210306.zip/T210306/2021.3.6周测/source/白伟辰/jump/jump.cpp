#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
using namespace std;
int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	srand(time(0)+19270817);
	int t;
	cin>>t;
	for(int t1=1;t1<=t;t1++){
		int n,m,x1,x2,y1,y2;
		scanf("%d%d%d%d%d%d",&n,&m,&x1,&x2,&y1,&y2);
		int k1,k2;
		cin>>k1>>k2;
		if(n==1||m==1)
			cout<<"YES"<<endl;
		else{
			if(k1>=k2)
				cout<<"NO"<<endl;
			else
				cout<<"YES"<<endl;
		}
	}
	return 0;
}
