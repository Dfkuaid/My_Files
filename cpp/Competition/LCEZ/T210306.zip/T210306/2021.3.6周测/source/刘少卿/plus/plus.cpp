#include<bits/stdc++.h>

using namespace std;

#define INF 1<<30
#define int long long

const int p= 998244353;

template<typename _T>
inline void read(_T &x)
{
	x=0;char s=getchar();int f=1;
	while(s<'0'||s>'9') {f=1;if(s=='-')f=-1;s=getchar();}
	while('0'<=s&&s<='9'){x=(x<<3)+(x<<1)+s-'0';x %= p ;s=getchar();}
	x*=f;
}

const int maxn = 1e5+5;

int a[maxn];
int jc[maxn];
int opi[maxn];
int Inv[maxn];
int q[23];
int pl,j,c;



int power(int a,int b)
{
	int ans = 1;
	while(b)
	{
		if(b&1) ans = (ans * a)%p;
		a = (a*a)%p;
		b>>=1;
	}
	return ans;
	
}

inline int inv(int a)
{
	return power(a,p-2);
}

inline int C(int a,int b)
{
	int x = jc[a] ;
	x = (x * Inv[b] ) %p;
	
//	if(a == q[b]) return 1;
	
	x = (x * opi[ a - q[b] ] ) %p;
	
	return x;
}
int n,m;
int fl;
//int Inv[2333];
//namespace T1{
//	
//	inline Cll(int a,int b)
//	{
//		int x = jc[a];
//		x = (x*inv(b))%p;
//		x = (x*inv(a - b))%p;
//		return x;
//	}
//	
//	inline int solve()
//	{
//		for(int i=1;i<=n;i++)
//		read(a[i]);
//		
//		for(int i=1,pl,j,c;i<=m;i++)
//		{
//			read(pl);
//			read(j);
//			read(c);
//			a[pl] += c;
//			for(int r=pl+1;r<=n;r++)
//			{
//				int x =  c * Cll( q[j] - pl  + r , q[j] )% p ;
//				a[r] =( a[r] + x) %p ;
//			}
//		
//		}
//		
//		for(int i=1;i<=n;i++) read(a[i]);
//		
//	}
//}

int f[13][maxn];

#define mod p

inline void pre()
{
	for(int i=1;i<=n;i++) Inv[i]=power(i,p-2);
	for(int i=1;i<=fl;i++) f[i][0]=1;
	for(int i=1;i<=fl;i++)
	{
		for(int j=1;j<=n;j++)
		{
			f[i][j]=f[i][j-1]%mod*((q[i]+j)%mod)%mod*Inv[j]%mod;
		}
	}
}

signed main()
{
	
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	
//	jc[1] = 1;
//	for(int i=2;i<=1e5+5;i++)
//	{
//		jc[i] = (jc[i-1] * i)%p;
//	}
//	
//	for(int i=1;i<=1e5+5;i++)
//	{
//		opi[i] = inv(jc[i]);
//	}
	
	read(n);
	read(fl);
	read(m);
	int ok = 1;
	for(int i=1;i<=fl;i++) 
	{
		read(q[i]);
//		if(q[i] > 256) ok = 1;
	}
	
//	if(ok) {T1::solve();
//	return 0;
//	}
	
//	for(int i=1;i<=fl;i++) 
//	{
////		read(q[i]);
//		if(!q[i]) Inv[i] = 0;
//		else Inv[i] = inv(jc[q[i]]);
//		
//	}
	
	for(int i=1;i<=n;i++) read(a[i]);
	
	pre();
	
	for(int i=1,pl,J,c;i<=m;i++)
	{
		read(pl);
		read(J);
		read(c);
//		a[pl] += c;
//		for(int r=pl+1;r<=n;r++)
//		{
//			int x =  c * C( q[j] - pl  + r , j )% p ;
//			a[r] =( a[r] + x) %p ;
//		}
		for(int j=pl;j<=n;j++)
		{
			(a[j]+=c%mod*f[J][j-pl]%mod)%=mod;
		}
	}
	
	for(int i=1;i<=n;i++)
	{
		printf("%lld ",a[i]);
	}
	
}
/*

10 1 3
4
0 0 0 0 0 0 0 0 0 0
1 1 1
5 1 1
7 1 2

*/
