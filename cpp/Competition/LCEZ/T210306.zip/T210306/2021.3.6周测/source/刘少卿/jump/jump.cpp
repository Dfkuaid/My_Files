#include<bits/stdc++.h>

using namespace std;

#define INF 1<<30
#define int long long 

template<typename _T>
inline void read(_T &x)
{
	x=0;char s=getchar();int f=1;
	while(s<'0'||s>'9') {f=1;if(s=='-')f=-1;s=getchar();}
	while('0'<=s&&s<='9'){x=(x<<3)+(x<<1)+s-'0';s=getchar();}
	x*=f;
}

signed main()
{
	int T;
	
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	
	read(T);
	
	while(T--)
	{
	int n,m,x,y,k; // �ط� 
	int xx,yy,kk;// ���� 
//	int k,kk;
	read(n);
	read(m);
	read(x); // 
	read(xx);
	read(y);
	read(yy);
	read(k);
	read(kk);
	
	int s = abs(x - xx) + abs(y - yy);
	
	if(n == 1 || m == 1) 
	{
		printf("YES\n");
		continue;
	}
	
	if(s%2)
	{
		if(kk > k)
		{
			printf("YES\n");
		}
		else printf("NO\n");
	}
	else
	{
		if(k > kk)
		{
			printf("NO\n");
		}
		else
		{
			printf("YES\n");
		}		
	}
			
	}
	
	

	
}

