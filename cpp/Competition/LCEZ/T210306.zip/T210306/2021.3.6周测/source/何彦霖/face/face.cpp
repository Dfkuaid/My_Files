#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N 2000010
#define M 20010
using namespace std;

const ll INF=0x3f3f3f3f;

long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

ll n,m;

struct rode{
	ll x,y,val,ans;
	dd minn;
	bool pd;
	
	inline void print(){
		printf("%lld %lld %lld\n",x,y,val);
	}
	
};
rode a[N+M];

inline dd dis(int b,int c){
	return sqrt((a[b].x-a[c].x)*(a[b].x-a[c].x)+(a[b].y-a[c].y)*(a[b].y-a[c].y));
}

struct Tree{
	struct node{
		int ls,rs,pos;
	};
	node p[N+M];int tail,root;
	
	inline tree(){
		tail=root=0;
		memset(p,0,sizeof(p));
	}
	
	inline void insert(int x,int k){
		if(k==0){
			if(root==0) root=1;
			p[++tail].pos=x;
			return;
		}
		if(a[x].val<=a[p[k].pos].val){
			if(a[p[k].pos].pd==1&&a[x].pd==0){
				if(a[p[k].pos].minn>dis(p[k].pos,x)){
					a[p[k].pos].ans=x;
				}
			}
			insert(x,p[k].ls);
			if(!p[k].ls) p[k].ls=tail;
		}
		else{
			insert(x,p[k].rs);
			if(!p[k].rs) p[k].rs=tail;
		}
	}
};
Tree t;

int main(){
	freopen("face.in","r",stdin);
	freopen("face.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++){
		ll x=read(),y=read(),v=read();
		a[i].x=x;a[i].y=y;a[i].val=v;a[i].pd=0;a[i].minn=-1;
	}
	for(int i=1;i<=m;i++){
		ll x=read(),y=read(),v=read();
		a[i+n].x=x;a[i+n].y=y;a[i+n].val=v;a[i+n].pd=1;a[i+n].minn=INF;
		t.insert(i+n,t.root);
	}
	for(int i=1;i<=n;i++) t.insert(i,t.root);
	for(int i=1;i<=m;i++){
		a[a[i+n].ans].print();
	}
	return 0;
}
