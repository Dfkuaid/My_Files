#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N 100105
#define M 11
using namespace std;

const ll mod= 998244353;

inline ll ksc(ll x,ll y){
	ll z=(ld)x/mod*y;
	ll res=(ull)x*y-(ull)mod*z;
	return (res%mod+mod)%mod;
}

inline long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

ll n,m,a[N],k[M],q,inv[N];

inline void solve(string s,int pos){
	ll num=0;
	for(int i=0;i<s.length();i++){
		num=(num<<1)+(num<<3)+s[i]-48;
		if(num>=mod) num%=mod;
	}
	k[pos]=num;
}

int main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	inv[1]=1;
	for(int i=2;i<=100100;i++) inv[i]=(mod-mod/i)*inv[mod%i]%mod;
	n=read();q=read();m=read();
	for(int i=1;i<=q;i++){
		string s;
		cin>>s;
		solve(s,i);
	}
	for(int i=1;i<=n;i++) a[i]=read()%mod;
	for(int i=1;i<=m;i++){
		ll pl=read(),j=read(),c=read()%mod;
		ll nowc=1;
		for(int q=pl;q<=n;q++){
			(a[q]+=ksc(c,nowc))%=mod;
			nowc=ksc(nowc,k[j]+q+1-pl);
			nowc=ksc(nowc,inv[q+1-pl]);
		}
	}
	for(int i=1;i<=n;i++) printf("%lld ",a[i]);
	return 0;
}
