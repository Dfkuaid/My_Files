#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<sstream>
#include<queue>
#include<map>
#include<vector>
#include<set>
#include<deque>
#include<cstdlib>
#include<ctime>
#define dd double
#define ld long double
#define ll long long
#define ull unsigned long long
#define N number
#define M number
using namespace std;

long long read()
{
	long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}

bool op;
ll t;
ll n,m,xa,xb,ya,yb,ka,kb;

int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	t=read();
	while(t--){
		op=false;
		n=read();m=read();xa=read();xb=read();ya=read();yb=read();
		ll len=abs(xa-xb)+abs(ya-yb)-1;
		if(len%2==0) op=1;
		ka=read();kb=read();
		if(op==1&&kb>ka) op=0;
		else if(op==0&&ka>kb) op=1;
		if(op) printf("NO\n");
		else printf("YES\n");
	}
	return 0;
}
