#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long int ll;
ll n,m,x1,yy1,x2,y2,k1,k2,T;
int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	scanf("%lld",&T);
	for(ll i=1;i<=T;i++){
		scanf("%lld%lld%lld%lld%lld%lld%lld%lld",&n,&m,&x1,&yy1,&x2,&y2,&k1,&k2);
		if(n==1||m==1){
			printf("YES\n");
			continue;
		}
		ll t;
		t=abs(x2-x1)+abs(y2-yy1);
		if(t%2){
			if(k2>k1)
			printf("YES\n");
			else
			printf("NO\n");
		}
		else{
			if(k1<=k2)
			printf("YES\n");
			else
			printf("NO\n");
		}
		
	}
	return 0;
}
