#include <cstdio>

using namespace std;

typedef unsigned long long int ll;
const int maxn=100005,mod=998244353;
ll n,q,m,k[maxn],pl,j,c,a[maxn];
int main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	scanf("%llu%llu%llu",&n,&q,&m);
	for(int i=1;i<=q;i++){
		scanf("%llu",&k[i]);
		k[i]=k[i]%mod;
	}
	for(int i=1;i<=n;i++){
		scanf("%llu",&a[i]);
		a[i]=a[i]%mod;
	}
	for(int i=1;i<=m;i++){
		ll x=1;
		scanf("%llu%llu%llu",&pl,&j,&c);
		pl=pl%mod;
		j=j%mod;
		c=c%mod;
		for(ll t=pl;t<=n;t++){
			(a[t]+=c*(ll)x)%=mod;
			a[t]=(a[t]%mod);
			x=(x*(k[j]+t-pl+1)%mod)/((t-pl+1)%mod)%mod;
			x%=mod;
			x=(x+mod)%mod;
			//x=(x/(t-pl+1));
			//a[t]+=c*zuhe(k[j]+t-pl,k[j]);
			a[t]=(a[t]%mod);
		}
	}
	for(int i=1;i<=n;i++){
		printf("%llu ",a[i]);
	}
	return 0;
}
//10 1 3 4 0 0 0 0 0 0 0 0 0 0 1 1 1 5 1 1 7 1 2
//10 3 4 998244353 1000000007 19260817 9 8 7 6 5 4 3 2 1 10 1 1 987654321 5 2 123456789 3 3 1919810 2 3 114514
