#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
using namespace std;

const int N = 100010;
const int INF = 0x3fffffff;

int t;

inline int _abs(int x){
    return x >= 0 ? x : -x;
}

int main(){
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    scanf("%d",&t);
    while (t --){
        int n,m,x1,x2,y1,y2,c1,c2;
        scanf("%d%d%d%d%d%d",&n,&m,&x1,&x2,&y1,&y2);
        scanf("%d%d",&c1,&c2);
        int len1 = _abs(x1 - x2);
        int len2 = _abs(y1 - y2);
        if (n == 1 || m == 1){
            cout << "YES\n";
            continue;
        }
        if ((len1 + len2) % 2){
            if (c1 >= c2)
              cout << "NO\n";
            else
              cout << "YES\n";
        }
        else if (c1 > c2)
          cout << "NO\n";
        else
          cout << "YES\n";
    }
    return 0;
}
