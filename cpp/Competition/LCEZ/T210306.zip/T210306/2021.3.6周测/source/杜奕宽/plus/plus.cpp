#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ll long long
#define ull unsigned long long
#define mset(l,x) memset(l,x,sizeof(l))
using namespace std;

const int N = 400010;
const int INF = 0x3fffffff;
const int Mod = 998244353;

ll n,q,m;
ull k[11],a[N];

inline ll read(){
    ll res = 0;
    int op = 1;
    char c = getchar();
    while (c < '0' || c > '9'){
        if (c == '-')
          op = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9'){
        res = (res * 10) + (int)(c - '0');
        res %= Mod;
        c = getchar();
    }
    return res;
}

inline ll ksm(ll x){
    ll res = 1;
    ll b = Mod - 2;
    while (b){
        if (b & 1)
          res = (res * x) % Mod;
        b >>= 1;
        x = (x * x) % Mod;
    }
    return res;
}

int main(){
    freopen("plus.in","r",stdin);
    freopen("plus.out","w",stdout);
    scanf("%lld%lld%lld",&n,&q,&m);
    for (int i = 1;i <= q;i ++)
        k[i] = read();
    for (int i = 1;i <= n;i ++){
        cin >> a[i];
    }
    while (m --){
        ll pl,j,c;
        scanf("%lld%lld%lld",&pl,&j,&c);
        ull dt = 1;
        for (int i = pl;i <= n;i ++){
            a[i] = (a[i] + (c * dt) % Mod) % Mod;
            dt = (dt * (k[j] + i + 1 - pl)) % Mod;
            dt = (dt * ksm(i + 1 - pl)) % Mod;
        }
    }
    for (int i = 1;i <= n;i ++)
      cout << a[i] << " ";
    return 0;
}
/*
10 3 4
998244353 1000000007 19260817
9 8 7 6 5 4 3 2 1 10
1 1 987654321
5 2 123456789
3 3 1919810
2 3 114514
*/
