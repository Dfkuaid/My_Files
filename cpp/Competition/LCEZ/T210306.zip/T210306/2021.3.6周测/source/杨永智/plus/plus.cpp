/*---------------------------------
 *Title number: L2OJ 
 *Creation date: 2021.2.25
 *Author: EdisonBa 
 *-------------------------------*/
#pragma GCC optimize(2)
#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <stack>
#include <cmath>
#include <queue>
#include <map>
#define rint register int
#define ull unsigned long long
using namespace std;
typedef long long ll;

const ll mod=998244353;
const ll maxn=1e5+10;
ll n,q,m;
ll a[maxn],k[maxn],jie[maxn],inv[maxn],f[11][maxn];

inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=((x<<1)+(x<<3)+ch-'0')%mod;
		ch=getchar();
	}
	return x*f;
}

inline ll ksm(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1) ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}

inline void pre()
{
	for(int i=1;i<=n;i++) inv[i]=ksm(i,mod-2);
	for(int i=1;i<=q;i++) f[i][0]=1;
	for(int i=1;i<=q;i++)
	{
		for(int j=1;j<=n;j++)
		{
			f[i][j]=f[i][j-1]%mod*((k[i]+j)%mod)%mod*inv[j]%mod;
		}
	}
}

int main(void)
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	
	n=read(),q=read(),m=read();
	
	for(int i=1;i<=q;i++) k[i]=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	pre();
	
	for(int i=1;i<=m;i++)
	{
		ll pl=read(),J=read(),c=read();
		
		for(int j=pl;j<=n;j++)
		{
			(a[j]+=c%mod*f[J][j-pl]%mod)%=mod;
		}
	}
	
	for(int i=1;i<n;i++) printf("%lld ",a[i]);
	
	printf("%lld",a[n]);
	
	return 0;
}
