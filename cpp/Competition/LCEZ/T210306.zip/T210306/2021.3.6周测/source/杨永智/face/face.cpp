
/*---------------------------------
 *Title number: L2OJ 
 *Creation date: 2021.2.25
 *Author: EdisonBa 
 *-------------------------------*/
#pragma GCC optimize(2)
#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <stack>
#include <cmath>
#include <queue>
#include <map>
#define rint register int
#define ull unsigned long long
using namespace std;
typedef long long ll;

inline ll read()
{
    ll x = 0, f = 0;
    char ch = getchar();
    while (!isdigit(ch))
        f |= (ch == '-'), ch = getchar();
    while (isdigit(ch))
        x = (x << 1) + (x << 3) + (ch ^= 48), ch = getchar();
    return f ? -x : x;
}

ll siz(ll xx1,ll xx2,ll yy1,ll yy2)
{
    ll xx=xx2-xx1;
    if(xx<0) xx*=-1;
    ll yy=yy2-yy1;
    if(yy<0) yy*=-1;
    return xx+yy;
}

ll n,m,b[2000004];

struct node{
    ll x,y,v,size;
}t[2000003];

bool cmp(node a,node b)
{
    if(a.size>b.size) return 1;
    if(a.size<b.size) return 0;
    if(a.v>b.v) return 1;
    return 0;
}
const int maxn=0x7fffffff;

int main()
{
    freopen("face.in","r",stdin);
    freopen("face.out","w",stdout);
    n=read();
    m=read();
    for(int i=1;i<=n;++i)
    {
        t[i].x=read();
        t[i].y=read();
        t[i].v=read();
        t[i].size=t[i].x+t[i].y;
    }
    sort(t+1,t+n+1,cmp);
    for(int i=1;i<=n;++i)
        b[i]=t[i].size;
    // for(int i=1;i<=n;++i)
    // {
    //     printf("%lld %lld %lld %lld\n",t[i].x,t[i].y,t[i].v,t[i].size);    
    // }
    for(int i=1;i<=m;++i)
    {
        ll x=read(),y=read(),v=read();
        ll si=x+y;
        ll mid=lower_bound(b+1,b+n+1,si)-b;
        ll s1=maxn,xx1,yy1,xx2,yy2,vv1,vv2,s2=maxn;
            for(int i=mid;i<=n;++i)
            {
                if(t[i].v<=v)
                {
                    s1=t[i].x+t[i].y;
                    xx1=t[i].x;
                    yy1=t[i].y;
                    vv1=t[i].v;
                    break;
                }
            }
            ll ans=s1-si;
                if(ans<0) ans*=-1;

            for(int i=mid-1;i>=1;--i)
            {
                if(t[i].v<=v)
                {
                    s2=t[i].x+t[i].y;
                    xx2=t[i].x;
                    vv2=t[i].v;
                    yy2=t[i].y;
                    break;
                }
            }

            ll ans1=s2-si;
                if(ans1<0) ans1*=-1;
            
            if(ans<ans1)
            {
                printf("%lld %lld %lld\n",xx1,yy1,vv1);
            }
            else
            {
                printf("%lld %lld %lld\n",xx2,yy2,vv2);
            }
  
    }
}
/*
3 3
1 1 1
3 2 3
2 3 2
2 2 1
2 2 2
2 2 3
*/