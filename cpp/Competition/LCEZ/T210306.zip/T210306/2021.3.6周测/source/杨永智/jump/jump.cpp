/*---------------------------------
 *Title number: L2OJ 
 *Creation date: 2021.2.25
 *Author: EdisonBa 
 *-------------------------------*/
#pragma GCC optimize(2)
#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <stack>
#include <cmath>
#include <queue>
#include <map>
#define rint register int
#define ull unsigned long long
using namespace std;
typedef long long ll;

inline ll read()
{
    ll x = 0, f = 0;
    char ch = getchar();
    while (!isdigit(ch))
        f |= (ch == '-'), ch = getchar();
    while (isdigit(ch))
        x = (x << 1) + (x << 3) + (ch ^= 48), ch = getchar();
    return f ? -x : x;
}

ll T,n,m,xx1,xx2,yy1,yy2,kk1,kk2;

ll siz()
{
    ll xx=xx2-xx1;
    if(xx<0) xx*=-1;
    ll yy=yy2-yy1;
    if(yy<0) yy*=-1;
    return xx+yy;
}

int main()
{
    // Xmz! Help me to get 100 points!!!
    // Thank you!!!
    freopen("jump.in","r",stdin);
    freopen("jump.out","w",stdout);
    T=read();
    while(T--)
    {
        n=read();
        m=read();
        xx1=read();
        xx2=read();
        yy1=read();
        yy2=read();
        kk1=read();
        kk2=read();
        if(n==1 || m==1)
        {
            puts("YES");
            continue;
        }
        else if(kk1==kk2)
        {
            if(siz()%2==1) puts("NO");
            else puts("YES");
            continue;
        }
        else
        {
            if(kk1>kk2)
            {
                puts("NO");
            }
            else 
            {
                puts("YES");
            }
            continue;
        }
    }
    return 0;
}
/*
5
2 8 1 1 2 5
9 9
3 5 3 3 2 3
2 2
6 3 4 1 1 1
3 4
3 3 1 3 3 3
8 7
2 9 2 1 9 2
6 5
*/
