#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#define ll long long
using namespace std;
const int mod=998244353;
int n,q,m;
ll a[100005],k[110],jc[100005],jcinv[100005];
ll f[15][100005];
inline ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=((x<<1)+(x<<3)+ch-'0')%mod;
		ch=getchar();
	}
	return x*f;
}
ll ksm(ll x,int a){
	ll sum=1;
	while(a){
		if(a&1) sum=(sum*x)%mod;
		x=(x*x)%mod;
		a>>=1;
	}
	return sum;
}
void inv(){
	jc[0]=1,jcinv[0]=1;
	for(ll i=1;i<=n;i++){
		jc[i]=jc[i-1]*i%mod;
		jcinv[i]=ksm(i,mod-2)%mod;
	}
}
void pre(){
	for(int j=0;j<=q;j++){
		for(int i=0;i<=n;i++){
			f[j][i]=1;
		}
	}
	for(int j=1;j<=q;j++){
		for(ll i=1;i<=n;i++){
			f[j][i]=f[j][i-1]*((k[j]+i)%mod)%mod*jcinv[i]%mod; //f[j][i]����C(k[j]+i,k[j]) 
//			printf("j=%d i=%d f[j][i]=%lld\n",j,i,f[j][i]);
		}
	}
}
int main()
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);

	scanf("%lld%lld%lld",&n,&q,&m);
	
	
	for(int i=1;i<=q;i++){
		k[i]=read();
//		printf("%lld ",k[i]);
	}
//	printf("\n");

	inv();
	pre();
	
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	
	for(ll p=1;p<=m;p++){
		ll pl,j,c,sum1=1,sum2=1;
//		scanf("%lld%lld%lld",&pl,&j,&c);
		pl=read(),j=read(),c=read();
		a[pl]=(a[pl]+c)%mod;
		for(int i=pl+1;i<=n;i++){
			a[i]=(a[i]+c*f[j][i-pl]%mod)%mod;
		}
	}
	
	for(int i=1;i<n;i++){
		printf("%lld ",a[i]);
	}
	printf("%lld",a[n]);
	return 0;
}

