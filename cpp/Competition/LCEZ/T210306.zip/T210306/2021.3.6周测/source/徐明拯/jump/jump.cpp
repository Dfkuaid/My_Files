#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int T,n,m,x1,x2,y1,y2,k1,k2;
int main()
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d%d%d%d%d%d",&n,&m,&x1,&x2,&y1,&y2);
		scanf("%d%d",&k1,&k2);
		if(n==1||m==1){
			printf("YES\n");
			continue;
		}
		int s=abs(x1-x2)+abs(y1-y2);
		if(s%2==0){
			if(k1>k2){
				printf("NO\n");
			}
			else{
				printf("YES\n");
			}
		}
		else{
			if(k1>=k2){
				printf("NO\n");
			}
			else{
				printf("YES\n");
			}
		}
	}
	return 0;
}
