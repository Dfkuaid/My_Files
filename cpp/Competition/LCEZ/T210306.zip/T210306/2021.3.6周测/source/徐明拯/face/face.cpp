#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#include<cmath>
#define ll long long
using namespace std;
int n,m;
struct Node{
	double x,y;
	int v;
}node[2000005];
double dis(double x1,double x2,double y1,double y2){
	double s1=(x1-x2)*(x1-x2);
	double s2=(y1-y2)*(y1-y2);
	double summ=sqrt(s1+s2);
	return summ;
}
int main()
{
	freopen("face.in","r",stdin);
	freopen("face.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%lf%lf%d",&node[i].x,&node[i].y,&node[i].v);
	}
	
	for(int j=1;j<=m;j++){
		double xx,yy;
		int vv;
		scanf("%lf%lf%d",&xx,&yy,&vv);
		int num;
		double minn=10000000000000000;
		for(int i=1;i<=n;i++){
			if(node[i].v<=vv&&dis(node[i].x,xx,node[i].y,yy)<minn){
				num=i;
				minn=dis(node[i].x,xx,node[i].y,yy);
			}
		}
		printf("%.0lf %.0lf %d\n",node[num].x,node[num].y,node[num].v);
	}
	return 0;
}

