#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<math.h>
#include<vector>
#include<queue>
#define ll int

inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

ll n,m,T;
ll x,y,a,b,p,q;

inline ll aabs(ll a)
{
	return a<0 ? -a : a;
}

int main(void)
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read(),m=read();
		x=read(),y=read(),a=read(),b=read(),p=read(),q=read();
		
		if(n==1||m==1)
		{
			printf("YES\n");continue;
		}
		
		if((aabs(x-a)+aabs(y-b))%2==0)
		{
			if(q>=p)
			{
				printf("YES\n");
			} 
			else
			{
				printf("NO\n");
			}
		} 
		else
		{
			if(q>p) printf("YES\n");
			else printf("NO\n");
		}
	}
	
	return 0;
}