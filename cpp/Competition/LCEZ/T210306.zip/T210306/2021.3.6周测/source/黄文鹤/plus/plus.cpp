//#pragma GCC optimize(2)
#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<math.h>
#include<queue>
#include<climits>
#define ll long long
#define ld long double

const ll mod=998244353;
const ll maxn=1e5+10;
ll n,q,m;
ll a[maxn],k[maxn],jie[maxn],inv[maxn],f[11][maxn];

inline ll read()
{
	ll x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while(isdigit(ch))
	{
		x=((x<<1)+(x<<3)+ch-'0')%mod;
		ch=getchar();
	}
	return x*f;
}

inline ll ksm(ll a,ll b)
{
	ll ret=1;
	while(b)
	{
		if(b&1) ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}

inline void pre()
{
	for(int i=1;i<=n;i++) inv[i]=ksm(i,mod-2);
	for(int i=1;i<=q;i++) f[i][0]=1;
	for(int i=1;i<=q;i++)
	{
		for(int j=1;j<=n;j++)
		{
			f[i][j]=f[i][j-1]%mod*((k[i]+j)%mod)%mod*inv[j]%mod;
		}
	}
}

int main(void)
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	
	n=read(),q=read(),m=read();
	
	for(int i=1;i<=q;i++) k[i]=read();
	for(int i=1;i<=n;i++) a[i]=read();
	
	pre();
	
	for(int i=1;i<=m;i++)
	{
		ll pl=read(),J=read(),c=read();
		
		for(int j=pl;j<=n;j++)
		{
			(a[j]+=c%mod*f[J][j-pl]%mod)%=mod;
		}
	}
	
	for(int i=1;i<n;i++) printf("%lld ",a[i]);
	printf("%lld",a[n]);
	
	return 0;
}