#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<functional>
#include<stack>
#include<queue>
#include<vector>
#include<bitset>
#include<set>
#include<map>
#define LL long long
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define Thispoint tr[k].l==tr[k].r
#define pushup tr[k].wei=tr[ls].wei+tr[rs].wei
#define pub push_back
#define lth length
#define pii pair<int,int>
#define mkp make_pair
using namespace std;
#define int LL
const int p=998244353;
inline void Read(int &x){
  int f=1;
  char c=getchar();
  x=0;
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;
    c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(10ll*x%p+c-48)%p;
    c=getchar();
  }
  x*=f,x=(x+p)%p;
}
const int N=100010;
int n,q,m,k[11],a[N],fac[N],inv[N];
int f[11][N];
il int Pow(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=1ll*res*a%p;
		a=1ll*a*a%p,b>>=1;
	}
	return res;
}
il void Init(){
	inv[1]=1;
	for(rg int i=2;i<=n;i++)inv[i]=((p-p/i*inv[p%i])%p+p)%p;
	for(rg int i=1;i<=q;i++){
		f[i][0]=1;
		for(rg int j=1;j<=n;j++){
			f[i][j]=1ll*f[i][j-1]*(k[i]+j)%p*inv[j]%p;
		}
	}
}
signed main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	Read(n),Read(q),Read(m);
	for(rg int i=1;i<=q;i++)Read(k[i]);
	Init();//O(nq)
	for(rg int i=1;i<=n;i++)Read(a[i]);
	for(rg int i=1,pl,j,c;i<=m;i++){//O(mn)
		Read(pl),Read(j),Read(c);
		for(rg int l=pl;l<=n;l++){
			a[l]=(a[l]+1ll*c*f[j][l-pl]%p)%p;
		}
	}
	for(rg int i=1;i<=n;i++)cout<<a[i]<<" ";
	return 0;
}
//expect:85
