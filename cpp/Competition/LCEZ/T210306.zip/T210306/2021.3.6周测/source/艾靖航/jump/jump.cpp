#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<functional>
#include<stack>
#include<queue>
#include<vector>
#include<bitset>
#include<set>
#include<map>
#define LL long long
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define Thispoint tr[k].l==tr[k].r
#define pushup tr[k].wei=tr[ls].wei+tr[rs].wei
#define pub push_back
#define lth length
#define pii pair<int,int>
#define mkp make_pair
using namespace std;
#define int LL
inline void Read(int &x){
  int f=1;
  char c=getchar();
  x=0;
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;
    c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(x<<3)+(x<<1)+c-'0';
    c=getchar();
  }
  x*=f;
}
int T,n,m,ax,ay,bx,by,k1,k2;
il int Dis(int ax,int ay,int bx,int by){
	return abs(ax-bx)+abs(ay-by);
}
signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	Read(T);
	while(T--){
		Read(n),Read(m),Read(ax),Read(bx);
		Read(ay),Read(by),Read(k1),Read(k2);
		if(n==1||m==1){
			cout<<"YES"<<endl;
			continue;
		}
		int d=Dis(ax,ay,bx,by);
		if(k1>=k2)cout<<"NO"<<endl;
		else cout<<"YES"<<endl;
	}
	return 0;
}
/*
expect:10
*/
