#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<functional>
#include<stack>
#include<queue>
#include<vector>
#include<bitset>
#include<set>
#include<map>
#define LL long long
#define rg register
#define il inline
#define us unsigned
#define eps 1e-6
#define INF 0x3f3f3f3f3f3f3f3f
#define ls k<<1
#define rs k<<1|1
#define tmid ((tr[k].l+tr[k].r)>>1)
#define nmid ((l+r)>>1)
#define Thispoint tr[k].l==tr[k].r
#define pushup tr[k].wei=tr[ls].wei+tr[rs].wei
#define pub push_back
#define lth length
#define pii pair<int,int>
#define mkp make_pair
using namespace std;
#define int LL
inline void Read(int &x){
  int f=1;
  char c=getchar();
  x=0;
  while(c<'0'||c>'9'){
    if(c=='-')f=-1;
    c=getchar();
  }
  while(c>='0'&&c<='9'){
    x=(x<<3)+(x<<1)+c-'0';
    c=getchar();
  }
  x*=f;
}
const int N=2000010,M=20010;
int n,m,t[N+M];
struct Node {
	int x,y,v,idx;
	Node(int _x=0,int _y=0,int _v=0,int _i=0){
		x=_x,y=_y,v=_v,idx=_i;
	}
}p[N];
bool operator < (Node a,Node b){
	return a.v<b.v;
}
struct Query {
	int x,y,v,idx,ans;
	Query(int _x=0,int _y=0,int _v=0,int _i=0){
		x=_x,y=_y,v=_v,idx=_i;
	}
}q[M];
bool operator < (Query a,Query b){
	return a.v<b.v;
}
il bool cmp(Query a,Query b){
	return a.idx<b.idx;
}
il int Dis(Node a,Node b){
	return (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y);
}
il int Find(Node u,int j){
	int mn=INF,res=0;
	for(rg int i=1;i<=j;i++){
		int d=Dis(u,p[i]);
		if(d<=mn){
			mn=d,res=i;
		}
	}
	return res;
}
signed main(){
	freopen("face.in","r",stdin);
	freopen("face.out","w",stdout);
	Read(n),Read(m);
	for(rg int i=1;i<=n;i++){
		Read(p[i].x),Read(p[i].y),Read(p[i].v);
		t[i]=p[i].v,p[i].idx=i;
	}
	for(rg int i=1;i<=m;i++){
		Read(q[i].x),Read(q[i].y),Read(q[i].v);
		t[i+n]=q[i].v,q[i].idx=i;
	}
	sort(t+1,t+1+n+m);
	int tmp=unique(t+1,t+1+n+m)-t-1;
	for(rg int i=1;i<=n;i++)p[i].v=lower_bound(t+1,t+1+tmp,p[i].v)-t;
	for(rg int i=1;i<=m;i++)q[i].v=lower_bound(t+1,t+1+tmp,q[i].v)-t;
	sort(p+1,p+1+n),sort(q+1,q+1+m);
	int j=0;
	for(rg int i=1;i<=m;i++){//O(nm)
		while(p[j+1].v&&p[j+1].v<=q[i].v)j++;
		q[i].ans=Find(Node(q[i].x,q[i].y,q[i].v),j);
	}
	sort(q+1,q+m+1,cmp);
	for(rg int i=1;i<=m;i++){
		Node u=p[q[i].ans];
		cout<<u.x<<" "<<u.y<<" "<<u.v<<endl;
	}
	return 0;
}
//expect:0
