#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define N 1000001
#define M 5001
#define INF 1100000000
#define Kafuu return
#define Chino 0
#define fx(l,n) inline l n
#define set(l,n,ty,len) memset(l,n,sizeof(ty)*len)
#define cpy(f,t,ty,len) memcpy(t,f,sizeof(ty)*len)
#define R register
#define C const
using namespace std;
int T,n,m,x1,x2,y1,y2,jn,yn,a,b;
fx(int,gi)(){
	R char c=getchar();R int s=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-') f=-f;
		c=getchar();
	}
	while(c<='9'&&c>='0') s=(s<<3)+(s<<1)+(c-'0'),c=getchar();
	return s*f;
}
fx(int,abs)(int a){
	return a>0?a:-a;
}
signed main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	T=gi();
	while(T--){
		n=gi(),m=gi(),x1=gi(),y1=gi(),x2=gi(),y2=gi();
		jn=gi(),yn=gi();
		if(n==1||m==1){
			printf("YES\n");
			continue;
		}
		a=abs(x1-x2)+abs(y1-y2);
		b=(jn-yn)>=0?(jn-yn):-1;
		if(jn==0&&yn==0){
			if(a%2) printf("NO\n");
			else printf("YES\n");
		} else {
			if(b>0||(b==0&&a%2)) printf("NO\n");
			else printf("YES\n");
		}
	}
}
