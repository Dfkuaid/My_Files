#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 1000001
#define INF 1100000000
#define Kafuu return
#define Chino 0
#define fx(l,n) inline l n
#define set(l,n,ty,len) memset(l,n,sizeof(ty)*len)
#define cpy(f,t,ty,len) memcpy(t,f,sizeof(ty)*len)
#define R register int
#define Co const
#define ll long long
const int mod=998244353,pr=3;
int n,ori[N],cf[N],invp,invx,x=1,br[N],prp[N],binom[N],T[N],q,m,k[11],stk[11];
struct operation{
	int pl,j,c;
}O[N],P[N];
fx(int,gi)(){
	register char C=getchar();ll s=0,f=1;
	while(C<'0'||C>'9'){
		if(C=='-') f=-f;
		C=getchar();
	}
	while(C>='0'&&C<='9') s=((s<<3)+(s<<1)+(C-'0'))%mod,C=getchar();
	return s*f;
}
fx(int,pow)(int a,int b=mod-2){
	ll sum=1;
	while(b){
		if(b&1) sum=sum*a%mod;
		a=1ll*a*a%mod;
		b>>=1;
	}
	return sum;
}
fx(void,NTT)(int *f,Co short r){
	R len,hl,exp,uni,st,i;
	for(i=0;i<x;i++) if(i<br[i]) std::swap(f[i],f[br[i]]);
	for(len=2,hl=1;len<=x;hl=len,len<<=1){
		exp=pow(r==1?pr:invp,(mod-1)/len);
		for(i=1;i<hl;i++) prp[i]=1ll*prp[i-1]*exp%mod;
		for(st=0;st<x;st+=len){
			for(i=0;i<hl;i++){
				uni=1ll*prp[i]*f[i|st|hl]%mod;
				f[i|st|hl]=(f[i|st]-uni+mod)%mod;
				f[i|st]=(f[i|st]+uni)%mod;
			}
		}
	}
	if(r==-1) for(i=0;i<x;i++) f[i]=1ll*f[i]*invx%mod;
}
fx(void,presum)(Co int bin,int *ori){
	set(binom,0,int,x);
	binom[0]=1;
	for(int i=1;i<=n;i++)
		binom[i]=1ll*binom[i-1]*(bin+i-1)%mod*pow(i)%mod;
	NTT(ori,1);NTT(binom,1);
	for(int i=0;i<x;i++)
		ori[i]=1ll*ori[i]*binom[i]%mod;
	NTT(ori,-1);
}
signed main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	n=gi(),q=gi(),m=gi();
	for(R i=1;i<=q;i++) k[i]=gi();
	for(R i=0;i<n;i++) ori[i]=gi();
	for(R i=1;i<=m;i++){
		O[i].pl=gi();
		O[i].j=gi();
		O[i].c=gi();
		stk[O[i].j]+=1;
	}
	for(R i=1;i<=10;i++)
		stk[i]+=stk[i-1];
	for(R i=m;i>=1;i--)
		P[stk[O[i].j]--]=O[i];
	while(x<=n+n) x<<=1;
	for(R i=0;i<x;i++) br[i]=(br[i>>1]>>1)|((i&1)?x>>1:0);
	invx=pow(x);invp=pow(pr);
	prp[0]=1;
	for(R kp=1,now=1,i;kp<=q;kp++){
		for(;P[now].j==kp&&now<=m;now++)
			(cf[P[now].pl-1]+=P[now].c)%=mod;
		presum(k[kp]+1,cf);
		for(i=0;i<n;i++)
			(ori[i]+=cf[i])%=mod;
		set(cf,0,int,x);
	}
	for(R i=0;i<n;i++) printf("%d ",ori[i]);
	Kafuu Chino;
}
