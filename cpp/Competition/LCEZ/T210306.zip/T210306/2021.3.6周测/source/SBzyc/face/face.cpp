#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define N 1000001
#define M 5001
#define INF 11000000000000
#define Kafuu return
#define Chino 0
#define fx(l,n) inline l n
#define set(l,n,ty,len) memset(l,n,sizeof(ty)*len)
#define cpy(f,t,ty,len) memcpy(t,f,sizeof(ty)*len)
#define int long long
#define R register
#define C const
using namespace std;
int n,node,root,x,y,k,m,cls,val;
struct point{
	int x,y,num,val;
	fx(bool,operator) < (const point &b) const{
		if(cls) return y<b.y;
		else return x<b.x;
	}
}p[N],cp[N];
struct KDTree{
	point p;
	int n,minx,miny,maxx,maxy,son[2],val;
}t[N];
struct nd{
	int dis,val,n;
}ans;
fx(int,gi)(){
	R char c=getchar();R int s=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-') f=-f;
		c=getchar();
	}
	while(c<='9'&&c>='0') s=(s<<3)+(s<<1)+(c-'0'),c=getchar();
	return s*f;
}
fx(nd,mknd)(int dis,int val,int n){
	nd a;
	a.dis=dis,a.val=val,a.n=n;
	return a;
}
fx(int,dis)(KDTree n,R int x,R int y){
	x=n.p.x-x;
	y=n.p.y-y;
	return x*x+y*y;
}
fx(int,kdmax)(KDTree n,R int x,R int y){R int x2,y2;
	x2=n.maxx-x;x=n.minx-x;
	y2=n.maxy-y;y=n.miny-y;
	return max(x*x,x2*x2)+max(y*y,y2*y2);
}
//fx(int,kdmax)(KDTree n,R int x,R int y){R int x2,y2;
//	x2=n.maxx-x;x=n.minx-x;
//	y2=n.maxy-y;y=n.miny-y;
//	return min(x*x,x2*x2)+min(y*y,y2*y2);
//}
fx(void,update)(C int n){
	if(!n) return;
	R int ls=t[n].son[0],rs=t[n].son[1];
	if(ls){
		t[n].minx=min(t[n].minx,t[ls].minx);
		t[n].miny=min(t[n].miny,t[ls].miny);
		t[n].maxx=max(t[n].maxx,t[ls].maxx);
		t[n].maxy=max(t[n].maxy,t[ls].maxy);
		t[n].val=min(t[n].val,t[ls].val);
	}
	if(rs){
		t[n].minx=min(t[n].minx,t[rs].minx);
		t[n].miny=min(t[n].miny,t[rs].miny);
		t[n].maxx=max(t[n].maxx,t[rs].maxx);
		t[n].maxy=max(t[n].maxy,t[rs].maxy);
		t[n].val=min(t[n].val,t[rs].val);
	}
}
fx(void,build)(R int &now,C int l,C int r,C int k){
	if(l>r) return;
	now=++node;cls=k;
	R int mid=(l+r)>>1;
	nth_element(p+l,p+mid,p+r+1);
	t[now].p=p[mid];
	t[now].n=p[mid].num;
	t[now].val=p[mid].val;
	t[now].minx=t[now].maxx=p[mid].x;
	t[now].miny=t[now].maxy=p[mid].y;
	if(l==r) return;
	build(t[now].son[0],l,mid-1,k^1);
	build(t[now].son[1],mid+1,r,k^1);
//	printf("[%d-%d] %d\n",l,r,t[now].val);
	update(now);
//	printf("[%d-%d] %d\n",l,r,t[now].val);
}
fx(void,query)(C int now,C int x,C int y,C int val){
	if(!now) return;
	R int dist=dis(t[now],x,y),lv=0,rv=0,ldis=0,rdis=0;
	
	if(val>=t[now].p.val&&dist<ans.dis)
		ans=mknd(dist,t[now].p.val,t[now].n);
//	printf("val: %d\n",ans.val);
	
	if(t[now].son[0]){
		lv=t[t[now].son[0]].val;
		ldis=kdmax(t[t[now].son[0]],x,y);
	}
	if(t[now].son[1]){
		rv=t[t[now].son[1]].val;
		rdis=kdmax(t[t[now].son[1]],x,y);
	}
//	printf("now: %d ansval: %d nowval: %d num: %d lv: %d rv: %d ldis: %d rdis: %d ansdis: %lld\n",now,val,t[now].p.val,t[now].p.num,lv,rv,ldis,rdis,ans.dis);
	if(ldis>rdis){
//		printf("f in\n");
		if(rv<=val) query(t[now].son[1],x,y,val);
		if(lv<=val) query(t[now].son[0],x,y,val);
	} else {
//		printf("r in\n");
		if(lv<=val) query(t[now].son[0],x,y,val);
		if(rv<=val) query(t[now].son[1],x,y,val);
	}
}
signed main(){
	freopen("face.in","r",stdin);
	freopen("face.out","w",stdout);
	n=gi();m=gi();
	for(R int i=1;i<=n;i++){
		p[i].x=gi();
		p[i].y=gi();
		p[i].val=gi();
		p[i].num=i;
		cp[i]=p[i];
	}
	build(root,1,n,0);
	for(R int i=1,o;i<=m;i++){
		x=gi(),y=gi(),val=gi();
		ans=mknd(INF,INF,0);
		query(root,x,y,val);
		printf("%d %d %d\n",cp[ans.n].x,cp[ans.n].y,cp[ans.n].val);
	}
}
