#include<bits/stdc++.h>
#define ll  unsigned long long
#define maxn 102000
#define mod 998244353

using namespace std;


inline int read()
{
    ll X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}


ll n,k[maxn],a[maxn],q,m;
ll p,j,c;
ll jiecheng[maxn];

ll pow(ll a, ll b, ll m)
{
    ll ans = 1;
    a %= m;
    while(b)
    {
        if(b & 1)ans = (ans % m) * (a % m) % m;
        b /= 2;
        a = (a % m) * (a % m) % m;
    }
    ans %= m;
    return ans;
}
ll inv(ll x, ll p)//x����p����Ԫ��pΪ����
{
    return pow(x, p - 2, p);
}
ll C(ll n, ll m, ll p)//�����C(n, m) % p
{
    if(m > n)return 0;
    ll up = 1, down = 1;//���ӷ�ĸ;
    for(int i = n - m + 1; i <= n; i++)up = up * i % p;
    for(int i = 1; i <= m; i++)down = down * i % p;
    return up * inv(down, p) % p;
}
ll Lucas(ll n, ll m, ll p)
{
    if(m == 0)return 1;
    return C(n % p, m % p, p) * Lucas(n / p, m / p, p) % p;
}


int main()
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	n=read();q=read();m=read();
	for(int i=1;i<=q;i++) k[i]=read();
	for(int i=1;i<=n;i++) a[i]=read();
	jiecheng[0]=1;
	/*for(int i=1;i<=maxn;i++)
	{
//		for(int k=1;k<=n;k++)
		jiecheng[i]=1;
		jiecheng[i]=(jiecheng[i-1]*i);
	}*/
	
//	for(int i=1;i<=maxn;i++) cout<<jiecheng[i]<<" ";
	
	while(m--)
	{
		ll u;
		p=read();j=read();c=read();
//		
		for(ll i=p;i<=n;i++)
		{
//			ll p=min(u,i);
//			a[i]=(ll)a[i]%mod+(ll)(c%mod)*(jiecheng[k[j]+i-p]%mod/(jiecheng[k[j]]%mod*jiecheng[i-p]%mod)%mod)%mod;
			/*a[i]=a[i]+c*(jiecheng[k[j]+i-p]/(jiecheng[k[j]]*jiecheng[i-p]));*/
			a[i]=(a[i]+c*Lucas(k[j]+i-p,k[j],mod))%mod;
//			cout<<i<<" iii "<<a[i]<<'\n';
//			cout<<jiecheng[k[j]+i-p]%mod<<" "<<jiecheng[k[j]]%mod<<" "<<jiecheng[i-p]%mod<<'\n';
//			cout<<k[j]+i-p<<" "<<k[j]<<" "<<i-p<<'\n';
//			cout<<p<<" ppp "<<'\n';
		}
//		cout<<'\n';
		
	 } 
	 
	for(int i=1;i<=n;i++) cout<<a[i]<<" ";
	cout<<'\n';
}

/*
10 1 3
4
0 0 0 0 0 0 0 0 0 0
1 1 1
5 1 1
7 1 2

*/
