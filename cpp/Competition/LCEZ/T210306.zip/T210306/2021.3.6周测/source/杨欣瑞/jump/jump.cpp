#include<bits/stdc++.h>
#define ll long long

using namespace std;
ll t,n,m,x,y,a,b;
ll num1,num2;

inline int read()
{
    ll X=0,w=0; char ch=0;
    while(!isdigit(ch)) {w|=ch=='-';ch=getchar();}
    while(isdigit(ch)) X=(X<<3)+(X<<1)+(ch^48),ch=getchar();
    return w?-X:X;
}

int main()
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		n=read();
		m=read();
		x=read();
		a=read();
		y=read();
		b=read();
		num1=read();
		num2=read();
		if(m==1||n==1) printf("YES\n");
		else if(num1==num2) 
		{
			if((abs(a-x)+abs(b-y))%2==1) printf("NO\n");
			else printf("YES\n");
		}
		else if(num1<num2) printf("YES\n");
		
		else if(num1>num2) printf("NO\n");
//		else cout<<"NO"<<'\n';
	}
	
	return 0;
}
