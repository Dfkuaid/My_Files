#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int n,m,x1;
int y_1,x2,y2,k1,k2,T;
int main()
{
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	cin>>T;
	while(T--)
	{
		scanf("%d%d%d%d%d%d%d%d",&n,&m,&x1,&x2,&y_1,&y2,&k1,&k2);
		if(n==1||m==1) cout<<"YES"<<endl;
		else if((abs(x1-x2)+abs(y_1-y2))%2==0) 
		{
			if(k1>k2) cout<<"NO"<<endl;
			else cout<<"YES"<<endl;
		}
		else
		{
			if(k1>=k2) cout<<"NO"<<endl;
			else cout<<"YES"<<endl;
		}
	}
	return 0;
}
//���������豣֤�Լ�ʣ����᲻����δ�����ߣ� 
