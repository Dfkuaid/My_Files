#include<iostream>
#include<cstdio>
using namespace std;
#define mod 998244353
long long ss[11],sr[500001],a[500001];
long long ch(long long a,long long b)
{
	long long ll=1;
	for(long long i=b+1;i<=a;i++)
	{
		ll=(ll*i);		
	}
	for(long long i=1;i<=a-b;i++)
		ll/=i;
	ll%=mod;
	return ll;
}
int main()
{
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
  long long n,q,m;
  cin>>n>>q>>m;
  for(long long i=1;i<=q;i++)
  	cin>>sr[i];  	
  for(long long i=1;i<=n;i++)
  {
  	cin>>a[i];  
		a[i]%=mod;	
	}
  for(long long i=1;i<=m;i++)
  {
  	long long pl,j,c;
  	cin>>pl>>j>>c;
  	for(long long o=pl;o<=n;o++)
  	{
  		a[o]=(a[o]+(c%mod)*(ch(sr[j]+o-pl,sr[j])%mod))%mod;
		}
	}
	for(long long i=1;i<=n;i++)
		cout<<a[i]<<" ";
  return 0;
}
