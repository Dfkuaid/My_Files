#include<bits/stdc++.h>
#define ll long long

using namespace std;
void read(int &x){
	x = 0; int f = 1;
	char c = getchar();
	while(!isdigit(c)){
		if(c == '-')	f = -1;
		c = getchar();
	}
	while(isdigit(c)){
		x = (x << 3) + (x << 1) + c - '0';
		c = getchar();
	}
	x *= f;
	return ;
}
//int f[10][10][10][10];
int n, m, x1, x2, Y1, y2, k1, k2, t;
//bool dfs(int x1, int x2, int y1, int y2, int k1, int k2, int turn){
//	printf("%d %d %d %d %d %d %d\n", x1, y1, x2, y2, k1, k2, turn);
//	if(f[x1][x2][y1][y2] != -1)	return f[x1][x2][y1][y2];
//	if(abs(x1 - x2) == 1 && abs(y1 - y2) == 1){
//		if(k1 > k2)	return f[x1][x2][y1][y2] = 0;
//		else return f[x1][x2][y1][y2] = 1;
//	}
//	if(turn == 1){
//		if(x1 + 1 <= n) if(!dfs(x1 + 1, x2, y1, y2, k1, k2, 2)) return f[x1][x2][y1][y2] =0;
//		if(x1 - 1 >= 1)	if(!dfs(x1 - 1, x2, y1, y2, k1, k2, 2)) return f[x1][x2][y1][y2] =0;
//		if(y1 + 1 <= m)	if(!dfs(x1, x2, y1 + 1, y2, k1, k2, 2)) return f[x1][x2][y1][y2] =0;
//		if(y1 - 1 >= 1)	if(!dfs(x1, x2, y1 - 1, y2, k1, k2, 2)) return f[x1][x2][y1][y2] =0;
//		if(k1 > 0) if(!dfs(x1, x2, y1, y2, k1 - 1, k2, 2)) return f[x1][x2][y1][y2] =0;
//		return f[x1][x2][y1][y2] = 1;
//	}
//	if(turn == 2){
//		if(x1 == x2 && abs(y1 - y2) <= 1)	return f[x1][x2][y1][y2] =1;
//		if(abs(x1 - x2) <= 1 && y1 == y2)	return f[x1][x2][y1][y2] =1;
//		if(x2 + 1 <= n)	if(dfs(x1, x2 + 1, y1, y2, k1, k2, 1))	return f[x1][x2][y1][y2] =1;
//		if(x2 - 1 >= 1)	if(dfs(x1, x2 - 1, y1, y2, k1, k2, 1))	return f[x1][x2][y1][y2] =1;
//		if(y2 + 1 <= m)	if(dfs(x1, x2, y1, y2 + 1, k1, k2, 1))	return f[x1][x2][y1][y2] =1;
//		if(y2 - 1 >= 1)	if(dfs(x1, x2, y1, y2 - 1, k1, k2, 1))	return f[x1][x2][y1][y2] =1;
//		return f[x1][x2][y1][y2] =0;
//	}
//}
int main(){
	freopen("jump.in","r",stdin);
	freopen("jump.out","w",stdout);
	read(t);
	
	while(t--){
		
//		for(int i = 0; i < 10; i++){
//			for(int j = 0; j < 10; ++j){
//				for(int k = 0; k < 10; ++k){
//					for(int p = 0; p < 10; ++p)	f[i][j][k][p] = -1;
//				}
//			}
//		}
//		memset(f, -1, sizeof(f));
//		read(n); read(m); read(x1); read(x2); read(Y1); read(y2); read(k1); read(k2);
//		printf("%s\n", dfs(x1, x2, Y1, y2, k1 > k2 ? k1 - k2 : 0, k1 > k2 ? 0 : k2 - k1, 1) ? "YES" : "NO");
		
		scanf("%d%d%d%d%d%d%d%d", &n, &m, &x1, &x2, &Y1, &y2, &k1, &k2);
		if(n == 1 || m == 1){
			printf("YES\n");	continue;
		}
		if(k1 == k2){
			if((abs(x1 - x2) + abs(Y1 - y2)) % 2 == 1){	printf("NO\n"); continue; }
			else printf("YES\n");
		} 
		else{
			if(k1 > k2){
				printf("NO\n");
			}
			else printf("YES\n");
		}	
			
//		}
//		else {
//			if(k1 > k2){
//				printf()
//			}
//		}	
//		printf("YES\n");
	}
	return 0;
}
