#include<bits/stdc++.h>
#define ll long long
#define mod 998244353 
using namespace std;
void read(ll &x){
	x = 0; ll f = 1;
	char c = getchar();
	while(!isdigit(c)){
		if(c == '-')	f = -1;
		c = getchar();
	}
	while(isdigit(c)){
		x = ((x << 3) + (x << 1) + c - '0') % mod;
		c = getchar();
	}
	x *= f;
	return ;
}
ll n, q, pl, J, c, m;
ll k[10010], a[10010];
ll getpow(ll x, ll b){
	ll res = 1;
	x %= mod;
	while(b){
		if(b & 1){
			res *= x;
		}
		b >>= 1;
		x *= x; x %= mod;
		res %= mod; 
	}
	return res;
}
ll getinv(ll x){
	return getpow(x, mod - 2);
}
ll getC(ll nn, ll mm){
	if(mm > nn)	return 0;
	ll res = 1;
	for(int i = nn; i > nn - mm; --i){
		res *= i; res %= mod;
	}
	for(int i = mm; i >= 1; --i){
		res *= getinv(i);	res %= mod;
	}
	return res;
}
ll lucas(ll nn, ll mm){
	if(!mm)	return 1;
	return getC(nn % mod, mm % mod) % mod * lucas(nn/mod, mm/mod) % mod;
}
int main(){
	freopen("plus.in","r",stdin);
	freopen("plus.out","w",stdout);
	read(n); read(q); read(m);
	for(int i = 1; i <= q; ++i){
		read(k[i]);
	}
	for(int i = 1; i <= n; ++i){
		read(a[i]);
	}
	while(m--){
		read(pl); read(J); read(c);
		for(int i = pl; i <= n; ++i){
			a[i] += lucas(k[J] + i - pl, k[J]) * c % mod;
		}
	}
	for(int i = 1; i <= n; ++i){
		printf("%lld ", a[i] % mod);
	}
	printf("\n");
	return 0;
}

